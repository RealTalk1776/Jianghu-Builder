//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-mYD2ecE4.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BLoPwY8B.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BLoPwY8B.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CwQTjqKy.js"]
	}
} });
//#endregion
export { tsrStartManifest };
