import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Copy, r as Check } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BVIwZ-Fj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var chant = {
	name: "Morale Chant",
	tag: "General",
	cited: true,
	detail: "About an 80% chance, on an attack or a heal, to gain a stack of Yi River. Each stack adds 1% physical damage and healing for 8 seconds. A flexible slot, not a reason to drop the Inner Way that actually changes your weapon."
};
var evasive = {
	name: "Evasive Charge",
	tag: "Arena",
	cited: true,
	detail: "A chance to refund endurance after a perfect dodge. Game8 slots it in 1v1 when you really dodge. It does nothing if you only deflect, block, or eat the hit."
};
var fury = {
	name: "Fury Harvest",
	tag: "Arena",
	cited: true,
	detail: "Attacks can restore Vitality. Worth a slot when Mystic Arts are the thing running dry. Skip it if you rarely spend Vitality."
};
var leech = {
	name: "Vital Leech",
	tag: "Execute",
	cited: true,
	detail: "An execution on an exhausted target heals you from the damage dealt. Real when fights end in exhaustion. Weak when nobody is allowed to sit in that window."
};
var KINDS = [
	"Sword",
	"Spear",
	"Blade",
	"Twinblades",
	"Fan",
	"Umbrella",
	"Rope Dart",
	"Gauntlets"
];
var ARTS = [
	{
		id: "nameless-sword",
		name: "Nameless Sword",
		kind: "Sword",
		path: "Bellstrike — Splendor",
		style: "Bellstrike",
		role: "Mobile damage",
		blurb: "Qi Shield into charged sword energy. The straightforward Bellstrike sword.",
		signature: {
			name: "Sword Morph",
			tag: "Core",
			cited: true,
			detail: "While Qi Shield is up, a charged attack spends extra endurance and throws a flurry of sword energy. Fearless Lunge and the martial skill are the easy ways to raise the shield. Upgrade this first."
		},
		second: {
			name: "Battle Anthem",
			tag: "Charged",
			cited: true,
			detail: "Raises charged-skill damage into bosses. Keep it when charges are the plan. It is a weak PvP slot, because the bonus is a boss mod."
		}
	},
	{
		id: "nameless-spear",
		name: "Nameless Spear",
		kind: "Spear",
		path: "Bellstrike — Splendor",
		style: "Bellstrike",
		role: "Poke and swap",
		blurb: "The spear half of Splendor. Endurance is the tax. Qiankun's Lock pays some of it back.",
		signature: {
			name: "Mountain's Might",
			tag: "Core",
			cited: true,
			detail: "Improves the endurance refund on Qiankun's Lock. The spear spends endurance to move and to hit, so this is the slot that keeps the loop from stalling."
		},
		second: {
			name: "Wildfire Spark",
			tag: "Endurance",
			cited: true,
			detail: "Refunds a cut of endurance when you attack. Pairs with Mountain's Might when the spear is the weapon that is actually moving."
		}
	},
	{
		id: "strategic-sword",
		name: "Strategic Sword",
		kind: "Sword",
		path: "Bellstrike — Umbra",
		style: "Bellstrike",
		role: "Bleed burst",
		blurb: "Single-target bleed and follow-up slashes. Higher ceiling in a duel than in a messy pull.",
		signature: {
			name: "Sword Horizon",
			tag: "Core",
			cited: true,
			detail: "After a Strategic Sword martial skill, charged skill, or special, you can follow with the cross-slash (listed as Crisscrossing Swords or Crosswind Blade). It applies bleed. It only functions on Strategic Sword."
		},
		second: {
			name: "Fivefold Bleed",
			tag: "Bleed",
			cited: true,
			detail: "Hits can stack bleed to five. The fifth stack clears into piercing damage. A second bleed source when Horizon is already the core."
		}
	},
	{
		id: "heavenquaker-spear",
		name: "Heavenquaker Spear",
		kind: "Spear",
		path: "Bellstrike — Umbra",
		style: "Bellstrike",
		role: "Bleed payoff",
		blurb: "The spear that cashes in Umbra's bleed. Fewer hits to fill the martial buff if Wolfchaser is socketed.",
		signature: {
			name: "Wolfchaser's Art",
			tag: "Core",
			cited: true,
			detail: "Lowers how many hits Heavenquaker needs to fill its martial buff, and a bleeding target can grant an extra combo point. This is the spear's reason to be in the pair."
		},
		second: {
			name: "Adaptive Steel",
			tag: "Shred",
			cited: true,
			detail: "On spears, hits ignore a slice of physical defense (guides print 12.5%). On Strategic Sword the same Inner Way is a chance to bleed after affinity damage instead."
		}
	},
	{
		id: "infernal-twinblades",
		name: "Infernal Twinblades",
		kind: "Twinblades",
		path: "Bamboocut — Wind",
		style: "Bamboocut",
		role: "Pressure",
		blurb: "Fast dual blades. Sin and the rage loop are the weapon. OnKamii's 1v1 board has the Wind pair at T0.",
		signature: {
			name: "Echoes of Oblivion",
			tag: "Core",
			cited: true,
			detail: "The Inner Way that changes the twinblade pressure loop. Light attacks stack the path's ignore-defense damage. Upgrade this before the flex slots."
		},
		second: {
			name: "Vendetta",
			tag: "Tokens",
			cited: true,
			detail: "The follow-up slot on Wind sheets when rope-dart tokens are part of the loop. Keep it if the dart is how you restart pressure."
		}
	},
	{
		id: "mortal-rope-dart",
		name: "Mortal Rope Dart",
		kind: "Rope Dart",
		path: "Bamboocut — Wind",
		style: "Bamboocut",
		role: "Chase",
		blurb: "The interrupt and chase tool beside Infernal Twinblades. High passive damage, and it hates getting parried in Rodent Rampage.",
		signature: {
			name: "Vendetta",
			tag: "Core",
			cited: true,
			detail: "Wind's rope-dart slot. Sheets put it next to Echoes of Oblivion when the dart is feeding the twinblade loop."
		},
		second: {
			name: "Breaking Point",
			tag: "Execute",
			cited: true,
			detail: "The fourth name on three Wind builds. Use it when the fight is about the execute. The effect text varies by patch, so read the tome before you level it past the cores."
		}
	},
	{
		id: "everspring-umbrella",
		name: "Everspring Umbrella",
		kind: "Umbrella",
		path: "Bamboocut — Dust",
		style: "Bamboocut",
		role: "Mobile area",
		blurb: "Dust's umbrella. Resonance is the loop. OnKamii lists the pair at T1 in high-rank 1v1.",
		signature: {
			name: "Phantom Rally",
			tag: "Core",
			cited: true,
			detail: "The umbrella anchor. Take it when Resonance is the thing you are actually playing."
		},
		second: {
			name: "Song of Tang",
			tag: "Sustain",
			cited: true,
			detail: "The sustained flex on Dust once the umbrella or the dart core is socketed."
		}
	},
	{
		id: "unfettered-rope-dart",
		name: "Unfettered Rope Dart",
		kind: "Rope Dart",
		path: "Bamboocut — Dust",
		style: "Bamboocut",
		role: "Sweep",
		blurb: "Dust's rope dart. Sweeps and multi-target control, not the Wind dart's chase loop.",
		signature: {
			name: "Towline Sweep",
			tag: "Core",
			cited: true,
			detail: "The dart anchor. Take it when the sweep, not umbrella Resonance, is the reason you equipped Dust."
		},
		second: {
			name: "Light Anew",
			tag: "Control",
			cited: true,
			detail: "Matters when you are controlling more than one target. A dead slot in a pure 1v1 that never sets up the control."
		}
	},
	{
		id: "heavenwill-gauntlets",
		name: "Heavenwill Gauntlets",
		kind: "Gauntlets",
		path: "Bamboocut — Kite",
		style: "Bamboocut",
		role: "Close burst",
		blurb: "Heaven's Will cash-out in melee. PvE lists put Kite in S. A spear mix is what 1v1 talk cites, not the designed pair alone.",
		signature: {
			name: "Soaring High",
			tag: "Core",
			cited: true,
			detail: "The gauntlet anchor when Heaven's Will is the cash-out you built the loop around."
		},
		second: {
			name: "Celestial Vigor",
			tag: "Support",
			cited: true,
			detail: "The comparison slot beside Soaring High on Kite primers. Keep it if the gauntlet, not the dart handoff, is starving."
		}
	},
	{
		id: "skygrasp-rope-dart",
		name: "Skygrasp Rope Dart",
		kind: "Rope Dart",
		path: "Bamboocut — Kite",
		style: "Bamboocut",
		role: "Setup",
		blurb: "Sets the Kite handoff into Falcon's Pursuit or Vile Condemned, then gets out.",
		signature: {
			name: "Sky Gripped",
			tag: "Core",
			cited: true,
			detail: "The dart anchor. Socket it when the rope dart is the setup and the gauntlets are the payoff."
		},
		second: {
			name: "Empirical Edge",
			tag: "Handoff",
			cited: true,
			detail: "The other Kite comparison piece. Use it when the dart-to-gauntlet handoff is the whole fight plan."
		}
	},
	{
		id: "skystrike-gauntlets",
		name: "Skystrike Gauntlets",
		kind: "Gauntlets",
		path: "Bamboocut — Draught",
		style: "Bamboocut",
		role: "Drunk burst",
		blurb: "Drunken Fist gauntlets. Damage lives in a short Deepdaze window. OnKamii calls the pair the most ping-dependent T0.",
		signature: {
			name: "Eonpour",
			tag: "Core",
			cited: true,
			detail: "The signature Draught tome. In the Inebriate state, path skills deal more base damage. At high tier it enables Drunkslay, which stores enhanced damage and detonates when the debuff ends. Level this before anything else on the path."
		},
		second: {
			name: "Volutefit",
			tag: "Guard",
			cited: true,
			detail: "Damage reduction during Winebound states. The survival piece for a burst that dies if you are interrupted."
		}
	},
	{
		id: "riven-twinblades",
		name: "Riven Twinblades",
		kind: "Twinblades",
		path: "Bamboocut — Draught",
		style: "Bamboocut",
		role: "Drunk burst",
		blurb: "The blade half of Draught. Skyspeak is what extends Deepdaze so the swap actually fits.",
		signature: {
			name: "Skyspeak",
			tag: "Core",
			cited: true,
			detail: "Extends Deepdaze for Riven Twinblades. Without it the drunken window is too short for the swap the path is built on."
		},
		second: {
			name: "Mistwing",
			tag: "Pen",
			cited: true,
			detail: "Penetration support for Draught. The freecast slot. Bench it in 1v1 if you cannot finish the window."
		}
	},
	{
		id: "vernal-umbrella",
		name: "Vernal Umbrella",
		kind: "Umbrella",
		path: "Silkbind — Jade",
		style: "Silkbind",
		role: "Ranged control",
		blurb: "Projectiles, a ranged stun, and space. Jade is T0 in 1v1 and S on Game8's PvP list. Patience beats greed.",
		signature: {
			name: "Blossom Barrage",
			tag: "Core",
			cited: true,
			detail: "The umbrella anchor on Jade primers. Socket it before the fan pieces."
		},
		second: {
			name: "Thunderous Bloom",
			tag: "Move",
			cited: true,
			detail: "The movement-heavy attack option once Blossom Barrage is in. Prefer it over Flying Gourds unless you want the fan's charge tradeoff."
		}
	},
	{
		id: "inkwell-fan",
		name: "Inkwell Fan",
		kind: "Fan",
		path: "Silkbind — Jade",
		style: "Silkbind",
		role: "Ranged punish",
		blurb: "The fan teleports and sets the punish after the umbrella has already made them miss.",
		signature: {
			name: "Star Reacher",
			tag: "Core",
			cited: true,
			detail: "The fan setup Inner Way. Pair it with Blossom Barrage, not instead of it, when both Jade weapons are out."
		},
		second: {
			name: "Flying Gourds",
			tag: "Tradeoff",
			cited: true,
			detail: "Only when you accept the Inkwell Fan charge tradeoff. Otherwise Thunderous Bloom is the cleaner fourth."
		}
	},
	{
		id: "panacea-fan",
		name: "Panacea Fan",
		kind: "Fan",
		path: "Silkbind — Deluge",
		style: "Silkbind",
		role: "Healer",
		blurb: "The group healer. In 1v1 it is a kite-and-cleanse duelist, ranked T3 / B, not a damage path.",
		signature: {
			name: "Royal Remedy",
			tag: "Core",
			cited: true,
			detail: "The Panacea healing loop. This is the tome you level before the umbrella pieces."
		},
		second: {
			name: "Restoring Blossom",
			tag: "Crit heal",
			cited: true,
			detail: "Rewards critical healing. It wants the crit rate Ivorybloom and the attribute row are already chasing."
		}
	},
	{
		id: "soulshade-umbrella",
		name: "Soulshade Umbrella",
		kind: "Umbrella",
		path: "Silkbind — Deluge",
		style: "Silkbind",
		role: "Healer",
		blurb: "Resource recovery for the fan. Not a second damage umbrella.",
		signature: {
			name: "Mending Loom",
			tag: "Core",
			cited: true,
			detail: "Umbrella resource recovery for Deluge. The slot that lets the fan keep casting."
		},
		second: {
			name: "Esoteric Revival",
			tag: "Revive",
			cited: true,
			detail: "A revive tool, not a general slot. Socket it for group content where a pick-up wins the fight. Bench it in 1v1."
		}
	},
	{
		id: "thundercry-blade",
		name: "Thundercry Blade",
		kind: "Blade",
		path: "Stonesplit — Might",
		style: "Stonesplit",
		role: "Counter tank",
		blurb: "Parry into Avalanche. You stand in the hit so the spear's taunt and your shields can matter.",
		signature: {
			name: "Exquisite Scenery",
			tag: "Core",
			cited: true,
			detail: "A successful parry skips a phase of Avalanche, on a cooldown. The blade's reason to parry instead of dodging out."
		},
		second: {
			name: "Art of Resistance",
			tag: "Shield",
			cited: true,
			detail: "Increases shield HP and the effects tied to that shield for a few seconds. It wants Trapped Beast and Predator's Shield in the same build."
		}
	},
	{
		id: "stormbreaker-spear",
		name: "Stormbreaker Spear",
		kind: "Spear",
		path: "Stonesplit — Might",
		style: "Stonesplit",
		role: "Taunt tank",
		blurb: "Storm Roar is the taunt. Rock Solid adds damage reduction and, on the tome, cuts your own damage by 10%.",
		signature: {
			name: "Rock Solid",
			tag: "Core",
			cited: true,
			detail: "Storm Roar grants extra damage reduction: more against a boss taunt, stacking against regular enemies. The tome also reduces the damage you deal by 10%. You are buying the right to stand there."
		},
		second: {
			name: "Trapped Beast",
			tag: "Emergency",
			cited: true,
			detail: "Below 30% HP, a shield for up to 30% of max HP. Long trigger gap. Pair it with Art of Resistance or accept it as the once-a-fight save."
		}
	},
	{
		id: "snowparting-blade",
		name: "Snowparting Blade",
		kind: "Blade",
		path: "Stonesplit — Strength",
		style: "Stonesplit",
		role: "Duel burst",
		blurb: "The Heng-style blade. Quicker than the charged Phalanxbane plan, which is why PvP sheets prefer it. The pair is T0 / S.",
		signature: {
			name: "Frost-Clad Night",
			tag: "Core",
			cited: true,
			detail: "A deflect, or a fully cast Grave Frost / Heng dual-weapon skill, unlocks Finding Spring: a fast follow-up that spends Blade Momentum and grants Tenacity. This is the PvP loop."
		},
		second: {
			name: "Invigorated Warrior",
			tag: "Conditional",
			cited: true,
			detail: "Damage and healing up while you are not being hit; getting hit shuts it off and raises damage taken for a few seconds. The client has also spelled this Envigorated. Risky in 1v1, fine if you are the one deflecting."
		}
	},
	{
		id: "phalanxbane-blade",
		name: "Phalanxbane Blade",
		kind: "Blade",
		path: "Stonesplit — Strength",
		style: "Stonesplit",
		role: "Charged damage",
		blurb: "The charged Stonesplit blade. Excellent into bosses that stand still. In a duel, players will not let the stacks live.",
		signature: {
			name: "Throat-Piercing Art",
			tag: "Core",
			cited: true,
			detail: "Combo hits stack Throat-Pierced. Stacks ignore some physical resistance and add critical damage. Game8 tells you to take it off in PvP, because a player will not let you hold the stacks."
		},
		second: {
			name: "Steadfast Devotion",
			tag: "Crit",
			cited: true,
			detail: "At tier 3, the Phalanxbane sheets use it so a high crit rate becomes a reliable crit. Keep it on the charged plan. It is not the 1v1 flex."
		}
	}
];
var suggest = {
	"nameless-sword": [
		{
			id: "nameless-spear",
			label: "Path pair",
			rank: "T1",
			board: "S",
			why: "Designed Splendor pair. Sword pressure, spear poke, one Bellstrike arsenal."
		},
		{
			id: "infernal-twinblades",
			label: "Ranked mix",
			rank: "T0",
			board: "Mix",
			why: "OnKamii ranks Nameless Sword with Infernal Twinblades at T0. Styles differ, so arsenal goes General."
		},
		{
			id: "strategic-sword",
			label: "Ranked mix",
			rank: "T2",
			board: "A",
			why: "Nameless Sword with either Umbra weapon is T2 on OnKamii and A on Game8. Same Bellstrike arsenal."
		}
	],
	"nameless-spear": [
		{
			id: "nameless-sword",
			label: "Path pair",
			rank: "T1",
			board: "S",
			why: "Designed Splendor pair."
		},
		{
			id: "heavenwill-gauntlets",
			label: "Ranked mix",
			rank: "Top mix",
			board: "Mix",
			why: "OnKamii has called Nameless Spear with Heavenwill Gauntlets his strongest pair. Styles differ."
		},
		{
			id: "strategic-sword",
			label: "Ranked mix",
			rank: "T0.5",
			board: "A",
			why: "Strategic Sword with Nameless Spear is T0.5 on OnKamii and A on Game8. Both are Bellstrike."
		}
	],
	"strategic-sword": [{
		id: "heavenquaker-spear",
		label: "Path pair",
		rank: "A",
		board: "A",
		why: "Designed Umbra pair. Bleed setup on the sword, payoff on the spear. Game8 PvP is A. The pure pair was not on the OnKamii top board we could read."
	}, {
		id: "nameless-spear",
		label: "Ranked mix",
		rank: "T0.5",
		board: "A",
		why: "The Umbra sword with the Splendor spear is the higher 1v1 mix."
	}],
	"heavenquaker-spear": [{
		id: "strategic-sword",
		label: "Path pair",
		rank: "A",
		board: "A",
		why: "Designed Umbra pair."
	}, {
		id: "nameless-sword",
		label: "Ranked mix",
		rank: "T2",
		board: "A",
		why: "Nameless Sword with an Umbra weapon sits at T2 / A."
	}],
	"infernal-twinblades": [{
		id: "mortal-rope-dart",
		label: "Path pair",
		rank: "T0",
		board: "A",
		why: "Designed Wind pair. OnKamii's second-best weapon pair in high-rank 1v1. Game8 PvP is A."
	}, {
		id: "nameless-sword",
		label: "Ranked mix",
		rank: "T0",
		board: "Mix",
		why: "The published T0 mix. You give up a shared arsenal path."
	}],
	"mortal-rope-dart": [{
		id: "infernal-twinblades",
		label: "Path pair",
		rank: "T0",
		board: "A",
		why: "Designed Wind pair."
	}],
	"everspring-umbrella": [{
		id: "unfettered-rope-dart",
		label: "Path pair",
		rank: "T1",
		board: "A",
		why: "Designed Dust pair. T1 in 1v1, A on Game8's PvP list."
	}],
	"unfettered-rope-dart": [{
		id: "everspring-umbrella",
		label: "Path pair",
		rank: "T1",
		board: "A",
		why: "Designed Dust pair."
	}],
	"heavenwill-gauntlets": [{
		id: "skygrasp-rope-dart",
		label: "Path pair",
		rank: "S PvE",
		board: "—",
		why: "Designed Kite pair. Both PvE lists put it in S. It was not on the 1v1 board we could read."
	}, {
		id: "nameless-spear",
		label: "Ranked mix",
		rank: "Top mix",
		board: "Mix",
		why: "The mix OnKamii has singled out above designed pairs."
	}],
	"skygrasp-rope-dart": [{
		id: "heavenwill-gauntlets",
		label: "Path pair",
		rank: "S PvE",
		board: "—",
		why: "Designed Kite pair."
	}],
	"skystrike-gauntlets": [{
		id: "riven-twinblades",
		label: "Path pair",
		rank: "T0",
		board: "A",
		why: "Designed Draught pair. T0, and the most ping-dependent duo on that board."
	}],
	"riven-twinblades": [{
		id: "skystrike-gauntlets",
		label: "Path pair",
		rank: "T0",
		board: "A",
		why: "Designed Draught pair."
	}],
	"vernal-umbrella": [{
		id: "inkwell-fan",
		label: "Path pair",
		rank: "T0",
		board: "S",
		why: "Designed Jade pair. Fourth-strongest on OnKamii's 1v1 board, S on Game8."
	}],
	"inkwell-fan": [{
		id: "vernal-umbrella",
		label: "Path pair",
		rank: "T0",
		board: "S",
		why: "Designed Jade pair."
	}],
	"panacea-fan": [{
		id: "soulshade-umbrella",
		label: "Path pair",
		rank: "T3",
		board: "B",
		why: "Designed Deluge pair. A healer in a duel is a kite plan, not a damage plan."
	}],
	"soulshade-umbrella": [{
		id: "panacea-fan",
		label: "Path pair",
		rank: "T3",
		board: "B",
		why: "Designed Deluge pair."
	}],
	"thundercry-blade": [{
		id: "stormbreaker-spear",
		label: "Path pair",
		rank: "T1",
		board: "B",
		why: "Designed Might pair. T1 in 1v1, B on Game8. You are there to live and to taunt."
	}],
	"stormbreaker-spear": [{
		id: "thundercry-blade",
		label: "Path pair",
		rank: "T1",
		board: "B",
		why: "Designed Might pair."
	}],
	"snowparting-blade": [{
		id: "phalanxbane-blade",
		label: "Path pair",
		rank: "T0",
		board: "S",
		why: "Designed Strength pair. One of OnKamii's top three, S on Game8. Lead with Snowparting in a duel."
	}],
	"phalanxbane-blade": [{
		id: "snowparting-blade",
		label: "Path pair",
		rank: "T0",
		board: "S",
		why: "Designed Strength pair. If the duel is the goal, treat Snowparting as the weapon you actually play."
	}]
};
var hawkwing = {
	name: "Hawkwing",
	where: "Weapons, pendant, disc",
	bonus: "2 pieces: Affinity Rate. 4 pieces: when damage triggers Affinity, gain a stack of physical attack (guides print +2% for 5 seconds, up to 5)."
};
var jadeware = {
	name: "Jadeware",
	where: "Weapons, pendant, disc",
	bonus: "2 pieces: Max Physical Attack. 4 pieces: a martial skill grants Jadeware, raising Affinity damage, with a further increase against controlled targets or targets under 40% Qi."
};
var swallow = {
	name: "Swallowcall",
	where: "Weapons, pendant, disc",
	bonus: "2 pieces: Min Physical Attack. 4 pieces: light attacks deal more damage under 40% Qi, and a little more against Exhausted targets."
};
var calmwaters = {
	name: "Calmwaters",
	where: "Armor",
	bonus: "2 pieces: Defense. 4 pieces: after a perfect dodge, a chance to restore a cut of max HP and some endurance. Game8's 1v1 armor on Splendor."
};
var formbend = {
	name: "Formbend",
	where: "Armor",
	bonus: "Named on Splendor sheets for the Qi-shield plan. It extends the shield and cuts damage while the shield is up. Read the four-piece in client before you craft past the first piece."
};
var rainwhisper = {
	name: "Rainwhisper",
	where: "Armor",
	bonus: "2 pieces: Max HP. 4 pieces: critical damage and healing up, and a further increase while an HP shield is active."
};
var ivory = {
	name: "Ivorybloom",
	where: "Weapons, pendant, disc",
	bonus: "2 pieces: Critical Rate. 4 pieces: at max HP, an extra chance for critical damage and healing, and those crits hit harder."
};
var whirlsnow = {
	name: "Whirlsnow",
	where: "Armor",
	bonus: "2 pieces: Physical Defense. 4 pieces: after a huge hit or after dropping under 20% HP, the next heal in a few seconds restores extra max HP. Once a minute."
};
var tiltrim = {
	name: "Tiltrim",
	where: "Weapons, pendant, disc",
	bonus: "The offensive set added for Draught. 2 pieces raise physical attack. 4 pieces grant Tiltrim for a few seconds when you deal damage during a martial special enhancement. Read the stack line in client. The September 2026 path notes name this set."
};
var brimflow = {
	name: "Brimflow",
	where: "Armor",
	bonus: "Draught's armor set. Stacks reduce damage taken, and at full stacks incoming critical and affinity damage drop further. The path notes name it beside Tiltrim."
};
var mistwillow = {
	name: "Mistwillow",
	where: "Weapons, pendant, disc",
	bonus: "The weapon set named on the Silkbind Jade PvP sheet as the general pick. The four-piece line was not printed on the page we used. Check the tooltip before you spend the materials."
};
var flawless = {
	name: "Flawless Defense",
	where: "Armor",
	bonus: "The armor set named for Jade in PvP, where survivability and anti-control rolls are allowed to beat a glass damage chest. Bonus text was not on the sheet we read."
};
var agile = {
	name: "Agile Steps",
	where: "Armor",
	bonus: "The PvP armor alternative named on Strength sheets, next to a Snowparting combo-damage roll on the chest. Bonus text was not printed in the extract."
};
var shattered = {
	name: "Shattered Ridge",
	where: "Weapons, pendant, disc",
	bonus: "Named as the Strength weapon set, with Rainwhisper listed as an alternative. The four-piece was not quoted in the sources we used."
};
var DUOS = [
	{
		ids: ["nameless-sword", "nameless-spear"],
		arenaRank: "T1",
		board: "S",
		mix: false,
		headline: "Sword pressure, spear poke",
		read: "Splendor is the clean Bellstrike duel. You are not the bleed path and you are not the tank. You swap, you shield, and you refuse to end the fight in one commitment.",
		arsenal: "Bellstrike",
		arsenalWhy: "Both weapons are Bellstrike, so the Bellstrike arsenal raises their attack. General is only for mixed styles.",
		source: "Game8 1v1 row (Sept 3, 2026) and the Splendor inner-way consensus. OnKamii 1v1, Sept 19, 2026: T1.",
		arena: {
			inner: [
				ARTS[0].signature,
				chant,
				fury,
				evasive
			],
			mystic: [
				{
					name: "Serene Breeze",
					tag: "Break",
					cited: true,
					detail: "Game8's 1v1 break. Use it to leave a combo, not as an opener."
				},
				{
					name: "Talon Strike",
					tag: "Punish",
					cited: true,
					detail: "Named on the Splendor 1v1 mystic row beside the break and the gap closer."
				},
				{
					name: "Cloud Steps",
					tag: "Gap",
					cited: true,
					detail: "The close. Also how you answer someone who tries to leave on their own step."
				},
				{
					name: "Dragon's Breath",
					tag: "Damage",
					cited: true,
					detail: "The damage mystic Game8 keeps from the PvE row. Drunken Poet and Soaring Spin are the other names on that list if Breath is contested."
				}
			],
			offense: jadeware,
			defense: calmwaters,
			gearNote: "Hawkwing is the simpler affinity alternative if you proc Affinity more often than you cast martial skills. Calmwaters is the 1v1 armor swap. Formbend is the Qi-shield chest if the fight is longer than a dodge war.",
			stats: [
				{
					name: "Affinity Rate",
					target: "Toward the 40% cap",
					detail: "Game8 stops at the cap, then leaves it. Past the cap is wasted."
				},
				{
					name: "Max Physical Attack",
					target: "Next",
					detail: "The attack stat once affinity is capped. Jadeware's 2-piece is the same stat."
				},
				{
					name: "Precision Rate",
					target: "About 85% on an affinity build",
					detail: "Game8's note: affinity does not depend on precision the way raw hits do, so 85% is the cited enough-point."
				},
				{
					name: "Critical Rate",
					target: "After precision",
					detail: "Real, but not ahead of the affinity cap or the attack stat."
				},
				{
					name: "Max Bellstrike Attack",
					target: "With the arsenal",
					detail: "Winds Meet Guide puts Bellstrike attack next to momentum and max physical. It only pays if the arsenal is Bellstrike."
				}
			],
			loop: "Light attacks on the sword, Homeless Charge as the poke, swap to the spear for the burst, Sword Conversion back. Do not empty endurance on one weapon. Perfect dodges are why Calmwaters and Evasive Charge are on the 1v1 row."
		},
		group: {
			inner: [
				ARTS[0].signature,
				ARTS[1].signature,
				chant,
				{
					name: "Insightful Strike",
					tag: "Duel",
					cited: true,
					detail: "Affinity damage builds Focus. At max Focus, Concentration adds affinity damage and a chance to take less on the next hit. Game8 likes it at high tier instead of a general slot. Battle Anthem stays on the bench here. Its bonus is for bosses."
				}
			],
			mystic: [
				{
					name: "Ghost Bind",
					tag: "Group",
					cited: true,
					detail: "MetaBattle's group pick. A root is worth more than a second gap closer when more than one person is hitting you."
				},
				{
					name: "Soaring Spin",
					tag: "Close",
					cited: true,
					detail: "The gap tool on both the PvE and PvP Splendor lists."
				},
				{
					name: "Dragon's Breath",
					tag: "Damage",
					cited: true,
					detail: "Still the damage mystic. In a pile, cast it when someone else has already stopped the target."
				},
				{
					name: "Drunken Poet",
					tag: "Burst",
					cited: true,
					detail: "Paired with Breath on the damage lists. At tier 3 it hits harder on your own Dark Scorch."
				}
			],
			offense: jadeware,
			defense: formbend,
			gearNote: "Group fights spend more time on the Qi shield than on perfect-dodge casino rolls. Formbend is the chest for that. Keep Jadeware.",
			stats: [
				{
					name: "Affinity Rate",
					target: "Toward 40%",
					detail: "Same cap. Insightful Strike is an affinity Inner Way, so the cap still comes first."
				},
				{
					name: "Max Physical Attack",
					target: "Next",
					detail: "Unchanged from the duel."
				},
				{
					name: "Momentum",
					target: "With attack",
					detail: "Winds Meet Guide lists momentum beside affinity and max physical for this weapon."
				},
				{
					name: "Critical Rate",
					target: "After",
					detail: "Do not cannibalize affinity to chase crit."
				}
			],
			loop: "Same swap, but you are allowed to spend the spear on a rooted target. Ghost Bind, then the sword's shielded charge, then out before the pile turns.",
			note: "Group here means a fight with more than one enemy, not a boss. Battle Anthem is a boss tome."
		}
	},
	{
		ids: ["strategic-sword", "heavenquaker-spear"],
		arenaRank: "A",
		board: "A",
		mix: false,
		headline: "Bleed, then make the spear shorter",
		read: "Umbra is a single-target bleed path with real crowd control. The pure pair is a Game8 A. The higher 1v1 citation is Strategic Sword with Nameless Spear, not this designed duo.",
		arsenal: "Bellstrike",
		arsenalWhy: "Both weapons are Bellstrike.",
		source: "Inner Ways: Game8, Winds Meet Guide, MetaBattle, as compared on the Umbra build page. Mystic PvP row: Game8. Gear: Hawkwing on the compared builds.",
		arena: {
			inner: [
				ARTS[2].signature,
				ARTS[3].signature,
				chant,
				{
					name: "Insightful Strike",
					tag: "Focus",
					cited: true,
					detail: "Game8 and Winds Meet Guide keep it as the fourth, and like it more at higher tiers. MetaBattle prints Breaking Point there instead. Pick Insightful if you live on affinity. Pick Breaking Point if the execute is the plan."
				}
			],
			mystic: [
				{
					name: "Serene Breeze",
					tag: "Break",
					cited: true,
					detail: "Game8's PvP mystic row for this path."
				},
				{
					name: "Cloud Steps",
					tag: "Gap",
					cited: true,
					detail: "On the same PvP row. Bleed does not help you if they leave."
				},
				{
					name: "Meridian Touch",
					tag: "Lock",
					cited: true,
					detail: "The ranged hold. Use it to make the bleed tick on a target that would otherwise kite the spear."
				},
				{
					name: "Leaping Toad",
					tag: "Arena",
					cited: true,
					detail: "The fourth name on that PvP row. The client marks Toad as an arena tool on other paths too."
				}
			],
			offense: hawkwing,
			defense: calmwaters,
			gearNote: "Hawkwing is the weapon set on the Umbra comparisons we read. They did not name a unique chest. Calmwaters is the Bellstrike 1v1 armor from the sister path, not an Umbra-specific citation.",
			stats: [
				{
					name: "Precision Rate",
					target: "High",
					detail: "Bleed and the spear buff both need the hit to land. No published cap unique to Umbra. Do not copy Splendor's 85% affinity note onto this path."
				},
				{
					name: "Affinity Rate",
					target: "Enough to feed Hawkwing and Adaptive Steel",
					detail: "Sword Horizon and the sword half of Adaptive Steel both care about affinity. Hawkwing's 4-piece is an affinity trigger."
				},
				{
					name: "Min Physical Attack",
					target: "With max",
					detail: "Bleed ticks and the spear's chip damage both like the floor of your attack, not only the ceiling."
				},
				{
					name: "Critical Rate",
					target: "After the hit rate",
					detail: "A crit on a miss is nothing. Precision stays ahead."
				},
				{
					name: "Max Bellstrike Attack",
					target: "Arsenal stat",
					detail: "Only while the arsenal stays Bellstrike."
				}
			],
			loop: "Strategic martial, charged, or special into the Horizon follow-up so the target is bleeding. Heavenquaker spends that bleed: Wolfchaser fills the spear buff in fewer hits and can grant an extra point on a bleeding body. Do not open with the spear into a target that is not bleeding yet."
		},
		group: { note: "The PvP mystic row is already the crowd-control row. It does not need a second sheet for a pile. Keep Horizon and Wolfchaser. Fivefold Bleed can replace Insightful Strike when you are hitting more than one body and Focus will not finish." }
	},
	{
		ids: ["infernal-twinblades", "mortal-rope-dart"],
		arenaRank: "T0",
		board: "A",
		mix: false,
		headline: "Do not get parried, do not drop rage",
		read: "Wind is the pressure pair. OnKamii puts it among the best 1v1 duos in the game. Game8's PvP letter is A, a step under the S paths. The gap is execution, not a missing tome.",
		arsenal: "Bamboocut",
		arsenalWhy: "Both weapons are Bamboocut.",
		source: "Dual-blades build page, version 2.2. Inner ways from the compared sheets. PvP mystics named there. OnKamii Sept 19, 2026.",
		arena: {
			inner: [
				ARTS[4].signature,
				ARTS[4].second,
				chant,
				{
					name: "Breaking Point",
					tag: "Fourth",
					cited: true,
					detail: "Three of the compared builds use Breaking Point. Game8's alternate fourth is Vital Leech. Take Leech only if your duels actually reach an execution."
				}
			],
			mystic: [
				{
					name: "Serene Breeze",
					tag: "Break",
					cited: true,
					detail: "On the Wind PvP mystic list."
				},
				{
					name: "Talon Strike",
					tag: "Punish",
					cited: true,
					detail: "On the same list."
				},
				{
					name: "Guardian Palm",
					tag: "Answer",
					cited: true,
					detail: "Named beside the break tools for Wind in PvP."
				},
				{
					name: "Ghostly Steps",
					tag: "Leave",
					cited: true,
					detail: "The disengage on that list. Wind dies when Rodent Rampage is parried and you have no way out."
				}
			],
			offense: swallow,
			defense: calmwaters,
			gearNote: "Swallowcall is the PvP weapon set on the dual-blades page. Hawkwing plus Eaglerise is the PvE pairing. If you stay on Hawkwing, raise affinity to the 16–20% band those sheets use. Swallowcall wants affinity kept low.",
			stats: [
				{
					name: "Precision Rate",
					target: "About 100%",
					detail: "Game8 and Snipzyte both sit here. Wind's damage is a lot of small hits. Misses fall off a cliff."
				},
				{
					name: "Critical Rate",
					target: "70–73% on Swallowcall",
					detail: "Game8's Swallowcall band. Hawkwing sheets use 65–70%. Snipzyte prints 76%. Do not mix the bands across sets."
				},
				{
					name: "Affinity Rate",
					target: "Low on Swallowcall",
					detail: "Game8 keeps it low on Swallowcall, 16–20% on Hawkwing, and Snipzyte prints 10%. Match the set you actually wear."
				},
				{
					name: "Min Physical Attack",
					target: "Then max",
					detail: "Swallowcall's 2-piece is minimum physical attack. Light attacks are the Swallowcall payoff."
				},
				{
					name: "Bamboocut Attack",
					target: "Arsenal",
					detail: "After the rates. Agility only if a talent on your gear has a gate."
				}
			],
			loop: "Build the twinblade resource, tag with the dart, and keep rage from falling off. If they start parrying Rodent Rampage, stop mashing it. That is the published failure state. Ghostly Steps is the leave button."
		},
		group: {
			mystic: [
				{
					name: "Ghost Bind",
					tag: "Group",
					cited: true,
					detail: "Named on the wider Wind mystic list for groups."
				},
				{
					name: "Dragon's Breath",
					tag: "Damage",
					cited: true,
					detail: "The PvE damage mystic. In a pile it is fine once someone else has stopped the target."
				},
				{
					name: "Serene Breeze",
					tag: "Break",
					cited: true,
					detail: "Still the break. A group fight does not make you immune to being combo'd."
				},
				{
					name: "Drunken Poet",
					tag: "Burst",
					cited: true,
					detail: "Paired with Breath on the damage lists."
				}
			],
			note: "Inner ways and Swallowcall stay. The mystic row is the part that opens up when you are not in a pure duel."
		}
	},
	{
		ids: ["everspring-umbrella", "unfettered-rope-dart"],
		arenaRank: "T1",
		board: "A",
		mix: false,
		headline: "Resonance or the sweep, not both at once",
		read: "Dust is mobile area damage. Pick the Inner Way that matches the weapon you are actually looping. The pair is T1 / A. A path-specific mystic list was not in the sources checked.",
		arsenal: "Bamboocut",
		arsenalWhy: "Both weapons are Bamboocut.",
		source: "Inner-way primer for Dust. Ranks from the version 2.2 tier comparison. Mystic names below are shared arena tools, marked as such.",
		arena: {
			inner: [
				ARTS[6].signature,
				ARTS[7].signature,
				ARTS[6].second,
				chant
			],
			mystic: [
				{
					name: "Cloud Steps",
					tag: "Staple",
					cited: false,
					detail: "Not printed on a Dust sheet we read. It is the gap tool every mobile 1v1 build is already using."
				},
				{
					name: "Serene Breeze",
					tag: "Staple",
					cited: false,
					detail: "Shared break. Dust's own mystic row was not in the primer."
				},
				{
					name: "Meridian Touch",
					tag: "Staple",
					cited: false,
					detail: "A hold, so the sweep has a body to land on. Not a Dust citation."
				},
				{
					name: "Ghost Bind",
					tag: "Staple",
					cited: false,
					detail: "The group-shaped hold. Bench it in a pure 1v1 for a second movement art if you own one."
				}
			],
			offense: hawkwing,
			defense: calmwaters,
			gearNote: "No Dust-specific set was pinned in the sources used. Hawkwing fits a path that hits often enough to stack affinity. Veil of the Willow is the other honest option if you weave light and heavy more than you proc affinity. Treat both as a fit, not a bible.",
			stats: [
				{
					name: "Precision Rate",
					target: "High",
					detail: "Area hits still miss. No Dust-specific number was printed."
				},
				{
					name: "Min Physical Attack",
					target: "With max",
					detail: "Chip and sweep damage care about the floor."
				},
				{
					name: "Bamboocut Attack",
					target: "Arsenal",
					detail: "Matching arsenal, or this line is ordinary physical attack and nothing more."
				},
				{
					name: "Critical Rate",
					target: "After precision",
					detail: "Do not buy crit by dumping precision."
				}
			],
			loop: "If Phantom Rally is socketed, play umbrella Resonance and use the dart to reposition. If Towline Sweep is the tome you trusted, the dart is the attack and the umbrella is the leave button. Light Anew only earns its slot when more than one enemy is controlled.",
			note: "Mystic row is not path-cited. Inner ways are."
		}
	},
	{
		ids: ["heavenwill-gauntlets", "skygrasp-rope-dart"],
		arenaRank: "S PvE",
		board: "—",
		mix: false,
		headline: "Setup dart, cash the gauntlet",
		read: "Kite is a close burst with a reposition. PvE lists put the designed pair in S. It was absent from the 1v1 board we could read. The duel citation that does exist is Heavenwill with Nameless Spear.",
		arsenal: "Bamboocut",
		arsenalWhy: "Both weapons are Bamboocut. Heavenwill also has a talent that wants Bamboocut attack.",
		source: "Inner-way primer. PvE ranks from the version 2.2 tier comparison. Mystic row is arena staples, not a Kite sheet.",
		arena: {
			inner: [
				ARTS[8].signature,
				ARTS[9].signature,
				ARTS[8].second,
				chant
			],
			mystic: [
				{
					name: "Cloud Steps",
					tag: "Staple",
					cited: false,
					detail: "The reposition Kite wants. Not printed on the primer."
				},
				{
					name: "Serene Breeze",
					tag: "Staple",
					cited: false,
					detail: "Shared break, so the gauntlet cash-out is not your death animation."
				},
				{
					name: "Talon Strike",
					tag: "Staple",
					cited: false,
					detail: "A punish after the dart connects. Not a Kite citation."
				},
				{
					name: "Leaping Toad",
					tag: "Staple",
					cited: false,
					detail: "Arena mobility. The client recommends it on other duel sheets. Not cited for Kite."
				}
			],
			offense: swallow,
			defense: calmwaters,
			gearNote: "No Kite set was named in the sources used. Swallowcall fits a light-attack cash-out. Hawkwing fits if Heaven's Will is proccing affinity instead. This is a fit, not a published Kite bible.",
			stats: [
				{
					name: "Precision Rate",
					target: "High",
					detail: "The handoff fails if the dart whiffs. No printed Kite number."
				},
				{
					name: "Min Physical Attack",
					target: "Then max",
					detail: "Close burst likes the floor of the hit."
				},
				{
					name: "Bamboocut Attack",
					target: "Arsenal",
					detail: "The gauntlet talent that adds Bamboocut damage does nothing on a mismatched arsenal."
				},
				{
					name: "Critical Rate",
					target: "After precision",
					detail: "Secondary."
				}
			],
			loop: "Dart setup into Falcon's Pursuit or Vile Condemned, gauntlets cash Heaven's Will, step out. Soaring High if the gauntlet is the star. Sky Gripped if the dart handoff is the star. Do not socket both and then play a third weapon's loop."
		}
	},
	{
		ids: ["skystrike-gauntlets", "riven-twinblades"],
		arenaRank: "T0",
		board: "A",
		mix: false,
		headline: "A short drunk window, or nothing",
		read: "Draught is the highest-variance T0. OnKamii calls it the most ping-dependent pair. The damage is compressed into Deepdaze. If the window is interrupted, the build did not happen.",
		arsenal: "Bamboocut",
		arsenalWhy: "Both weapons are Bamboocut.",
		source: "Draught inner ways and Tiltrim / Brimflow from the version 2.1 path notes and Game8's set section. Mystic names for this path were not in the pages we could quote.",
		arena: {
			inner: [
				ARTS[10].signature,
				ARTS[11].signature,
				ARTS[10].second,
				chant
			],
			mystic: [
				{
					name: "Serene Breeze",
					tag: "Staple",
					cited: false,
					detail: "Not on a Draught mystic list we could quote. You still need a break, because a stunned Deepdaze is zero damage."
				},
				{
					name: "Cloud Steps",
					tag: "Staple",
					cited: false,
					detail: "The window is a few seconds. Be in range before it starts. Not a path citation."
				},
				{
					name: "Talon Strike",
					tag: "Staple",
					cited: false,
					detail: "A punish inside the window. Not path-cited."
				},
				{
					name: "Guardian Palm",
					tag: "Staple",
					cited: false,
					detail: "An answer tool from the other Bamboocut PvP list. Use it if you own it. It is not a Draught citation."
				}
			],
			offense: tiltrim,
			defense: brimflow,
			gearNote: "Tiltrim and Brimflow are the sets the path update named. Do not replace them with Hawkwing unless the substats on Tiltrim are actually dead. Attunements that buff random attacks are worth less than ones that buff the enhanced skills inside the burst.",
			stats: [
				{
					name: "Min Physical Attack",
					target: "With max",
					detail: "The burst is a few enhanced hits. Both ends of physical attack matter, and the arsenal should be Bamboocut so they are the right attack type."
				},
				{
					name: "Bamboocut Attack",
					target: "Arsenal",
					detail: "Same reason."
				},
				{
					name: "Precision Rate",
					target: "Enough that the window connects",
					detail: "A miss inside Deepdaze is the whole build. No printed Draught percentage."
				},
				{
					name: "Critical Rate",
					target: "Inside the window",
					detail: "Crits on the stored Drunkslay hit are the ones that count. Do not buy them by dumping precision."
				}
			],
			loop: "Intoxication starts low, drunk opens at the top of the first threshold, and pushing the gauge into the dead high end is how you lose your own damage. Spend Deepdaze, swap while Skyspeak is extending it, detonate. If your ping cannot finish that, this is the wrong T0.",
			note: "Mystic names are staples. Eonpour, Skyspeak, Volutefit, Tiltrim, and Brimflow are the cited pieces."
		},
		group: {
			inner: [
				ARTS[10].signature,
				ARTS[11].signature,
				ARTS[11].second,
				chant
			],
			note: "In a group fight where you are allowed to freecast, Mistwing's penetration replaces Volutefit's guard. If you are the one being focused, stay on the arena row."
		}
	},
	{
		ids: ["vernal-umbrella", "inkwell-fan"],
		arenaRank: "T0",
		board: "S",
		mix: false,
		headline: "Make them miss, then Spring Away",
		read: "Jade is a ranged duel. T0 and S. The plan is patience. The umbrella owns space. The fan punishes the overcommit. Jadewind Shield is not a wall.",
		arsenal: "Silkbind",
		arsenalWhy: "Both weapons are Silkbind.",
		source: "Silkbind Jade PvP sheet, checked Oct 11, 2026, for mystics, Mistwillow, and Flawless Defense. Inner ways from the primer, which that PvP page did not restate.",
		arena: {
			inner: [
				ARTS[12].signature,
				ARTS[13].signature,
				ARTS[12].second,
				chant
			],
			mystic: [
				{
					name: "Cloud Steps",
					tag: "Space",
					cited: true,
					detail: "The PvP page's tool for opening or closing distance, and for knocking another umbrella player out of the air."
				},
				{
					name: "Serene Breeze",
					tag: "Break",
					cited: true,
					detail: "Breaks combos. The page treats the mystic row as defensive first."
				},
				{
					name: "Wolflike Frenzy",
					tag: "Surprise",
					cited: true,
					detail: "The surprise tool on that sheet. Do not spend it as a poke."
				},
				{
					name: "Meridian Touch",
					tag: "Hold",
					cited: false,
					detail: "Not on the four-name Jade duel blurb. A hold if Wolflike Frenzy is on cooldown and you need the body to stay."
				}
			],
			offense: mistwillow,
			defense: flawless,
			gearNote: "Mistwillow on the weapons, Flawless Defense on the armor. The PvP page says survivability or anti-control rolls can outrank a pure damage line. We do not have the four-piece sentences, so this row names the sets and stops.",
			stats: [
				{
					name: "Silkbind Attack",
					target: "First attack stat",
					detail: "The arsenal stat. The PvP page did not print a target number. It did say the plan is patient, so glass-cannon rolls are the wrong reading."
				},
				{
					name: "Precision Rate",
					target: "Projectiles have to land",
					detail: "A ranged stun that misses is you standing still."
				},
				{
					name: "Max HP",
					target: "With the attack stat",
					detail: "You win by still being alive when they overcommit. Damage reduction rolls are in the same family."
				},
				{
					name: "Critical Rate",
					target: "After",
					detail: "The punish should crit. It should not be the reason you fold to the first engage."
				}
			],
			loop: "Probe with umbrella projectiles. Let them spend mobility. When a stun lands, Spring Away (the charged light) is the punish. Unfading Flower zones and buys a reset. Cancel the long casts. Against another umbrella, deflect Spring Away or Cloud Steps them out of the air. Do not trust Jadewind Shield. Some attacks go around it."
		}
	},
	{
		ids: ["panacea-fan", "soulshade-umbrella"],
		arenaRank: "T3",
		board: "B",
		mix: false,
		headline: "You are the healer who refuses the duel",
		read: "Deluge is a healer path. In a group that is the job. In 1v1 it is T3 / B, and the win condition is kiting, not a damage rotation you do not have.",
		arsenal: "Silkbind",
		arsenalWhy: "Both weapons are Silkbind. Healing still wants the attack stats the fan scales from, which is why minimum physical attack shows up on healer sheets.",
		source: "Healer build page, version 2.2. PvP swaps called out there: Rainwhisper, and the defensive mystic list.",
		arena: {
			inner: [
				ARTS[14].signature,
				ARTS[14].second,
				ARTS[15].signature,
				chant
			],
			mystic: [
				{
					name: "Serene Breeze",
					tag: "Break",
					cited: true,
					detail: "On the healer PvP swap list."
				},
				{
					name: "Wolflike Frenzy",
					tag: "Surprise",
					cited: true,
					detail: "On the same PvP list. A disengage dressed as an attack."
				},
				{
					name: "Free Morph",
					tag: "Leave",
					cited: true,
					detail: "Named on the healer PvP mystic swap."
				},
				{
					name: "Leaping Toad",
					tag: "Arena",
					cited: true,
					detail: "The fourth PvP name on that sheet."
				}
			],
			offense: ivory,
			defense: rainwhisper,
			gearNote: "Ivorybloom stays, because crit healing is the stat the inner ways want. Rainwhisper is the PvP armor swap from the healer page. Whirlsnow is the emergency-heal alternative if you are the one being trained.",
			stats: [
				{
					name: "Critical Rate",
					target: "First",
					detail: "Game8 and the healer sheets lead with crit because Restoring Blossom and Ivorybloom are crit-healing tools."
				},
				{
					name: "Min Physical Attack",
					target: "Next",
					detail: "Called out on healer gear notes. A lot of the fan's healing cares about the floor of attack, not a huge maximum."
				},
				{
					name: "Silkbind Attack",
					target: "Arsenal",
					detail: "Winds Meet Guide's attack line for the path."
				},
				{
					name: "Max HP",
					target: "You cannot heal from zero",
					detail: "In 1v1 this climbs the list. A dead healer has a crit rate of zero."
				}
			],
			loop: "Do not chase. Panacea's loop is the heal and the cleanse. The umbrella restores the resource. In a duel you are trying to make them waste their gap closers, then you leave with the PvP mystic row. You will not out-damage Wind or Strength."
		},
		group: {
			mystic: [
				{
					name: "Golden Body",
					tag: "Save",
					cited: true,
					detail: "On the healer mystic list. The group save."
				},
				{
					name: "Meridian Touch",
					tag: "Hold",
					cited: true,
					detail: "A pick tool when your damage dealers need a body to stay still."
				},
				{
					name: "Flute of the Tides",
					tag: "Opener",
					cited: true,
					detail: "Named on the healer list. Cast it before the party commits, not after everyone is dead."
				},
				{
					name: "Cloud Steps",
					tag: "Reach",
					cited: true,
					detail: "How you reach the person who is actually dying, instead of the person standing next to you."
				}
			],
			offense: ivory,
			defense: {
				name: "Eaglerise",
				where: "Armor",
				bonus: "Named as a healer armor option beside Ivorybloom. The four-piece text was not quoted in the sources we used. Rainwhisper remains the shield-and-crit alternative."
			},
			gearNote: "Group healing wants Ivorybloom's crit at high HP. Keep yourself topped so the 4-piece is on.",
			note: "Esoteric Revival can replace Morale Chant when your group actually dies and a revive wins. It is a bad default."
		}
	},
	{
		ids: ["thundercry-blade", "stormbreaker-spear"],
		arenaRank: "T1",
		board: "B",
		mix: false,
		headline: "Stand there on purpose",
		read: "Might is the counter tank. T1 in 1v1, B on Game8's damage-leaning PvP list. You give up damage, on Rock Solid's own text, to be the person who does not move.",
		arsenal: "Stonesplit",
		arsenalWhy: "Both weapons are Stonesplit.",
		source: "Inner-way descriptions from the Fextralife weapon notes and the primer. Rank from the version 2.2 comparison. Mystic names are defensive staples, not a Might-specific sheet.",
		arena: {
			inner: [
				ARTS[17].signature,
				ARTS[16].signature,
				ARTS[16].second,
				leech
			],
			mystic: [
				{
					name: "Serene Breeze",
					tag: "Staple",
					cited: false,
					detail: "A break so a combo does not delete the shield plan. Not printed on a Might mystic list we read."
				},
				{
					name: "Golden Body",
					tag: "Staple",
					cited: false,
					detail: "A save. It appears on the healer list. It fits a tank who is the focus. Not a Might citation."
				},
				{
					name: "Cloud Steps",
					tag: "Staple",
					cited: false,
					detail: "You are slow. One gap tool is how you reach the person you mean to taunt."
				},
				{
					name: "Leaping Toad",
					tag: "Staple",
					cited: false,
					detail: "Arena mobility. Not path-cited."
				}
			],
			offense: {
				name: "Rainwhisper",
				where: "Weapons, pendant, disc",
				bonus: "Used here as the shield set, not the armor. 4 pieces raise critical damage and healing further while a shield is up. Art of Resistance and Trapped Beast are shields. If your client only allows Rainwhisper on armor, wear it there and put a physical set on the weapons."
			},
			defense: whirlsnow,
			gearNote: "Might sheets we read name the inner ways more clearly than the sets. Rainwhisper matches a shield loop. Whirlsnow is the once-a-minute save when the shield was not enough. Do not wear a glass offense set and then call it a tank.",
			stats: [
				{
					name: "Max HP",
					target: "First",
					detail: "Shields and the emergency heal scale off the body you brought."
				},
				{
					name: "Physical Defense",
					target: "With HP",
					detail: "You are going to get hit on purpose."
				},
				{
					name: "Min Stonesplit Attack",
					target: "So the taunt is not empty",
					detail: "Rock Solid already cuts your damage by 10%. You still need enough attack that Storm Roar is a threat."
				},
				{
					name: "Precision Rate",
					target: "Storm Roar has to connect",
					detail: "A missed taunt is you standing in the open for free."
				}
			],
			loop: "Storm Roar, take the Rock Solid reduction, parry into Avalanche with Exquisite Scenery, and hold Predator's Shield for the moment you drop. Trapped Beast is the panic shield under 30%. Do not play this like Strength. You will lose the deflect race."
		},
		group: {
			inner: [
				ARTS[17].signature,
				ARTS[16].signature,
				ARTS[16].second,
				ARTS[17].second
			],
			note: "In a pile, Trapped Beast replaces Vital Leech. Executions are less reliable when six people are hitting the same body. The shield is the group tool."
		}
	},
	{
		ids: ["snowparting-blade", "phalanxbane-blade"],
		arenaRank: "T0",
		board: "S",
		mix: false,
		headline: "Deflect, follow up, leave the long charge",
		read: "Strength is the consensus duel path. T0 and S. Play Snowparting. Phalanxbane's charged plan is the boss version, and Game8 takes its best inner way off for PvP.",
		arsenal: "Stonesplit",
		arsenalWhy: "Both weapons are Stonesplit.",
		source: "Stonesplit Strength build page, version 2.2, last checked Oct 7, 2026. Inner ways compared across g drag, hkurosagi, and Game8.",
		arena: {
			inner: [
				ARTS[18].signature,
				chant,
				fury,
				evasive
			],
			mystic: [
				{
					name: "Serene Breeze",
					tag: "Break",
					cited: true,
					detail: "Game8's PvP mystic row for Strength."
				},
				{
					name: "Talon Strike",
					tag: "Punish",
					cited: true,
					detail: "On that same row."
				},
				{
					name: "Leaping Toad",
					tag: "Arena",
					cited: true,
					detail: "The in-game tag on g drag's loadout calls Toad recommended for Arena. Game8 lists it as a Dragon Head alternative."
				},
				{
					name: "Dragon Head",
					tag: "Fill",
					cited: true,
					detail: "The other PvP name on the Game8 row. A filler when endurance is gone, not the opener."
				}
			],
			offense: shattered,
			defense: agile,
			gearNote: "PvE sheets name Shattered Ridge on the weapons, with Rainwhisper as an alternative, and Obsidian armor with Eaglerise as an alternative. For PvP the named armor alternative is Agile Steps, and the chest roll they call out is Snowparting combo damage rather than a Phalanxbane charged-skill boost.",
			stats: [
				{
					name: "Precision Rate",
					target: "95–100%",
					detail: "Game8 for both modes. hkurosagi sits at 100%."
				},
				{
					name: "Critical Rate",
					target: "75–80%",
					detail: "Game8's PvP band, and the Snowparting PvE band. The Phalanxbane boss plan can live lower if Steadfast Devotion tier 3 is carrying crits. That is not this row."
				},
				{
					name: "Max Physical Attack",
					target: "Then minimum",
					detail: "Game8 puts both attack stats after the rates."
				},
				{
					name: "Min Physical Attack",
					target: "With the max",
					detail: "The follow-up slashes are not single huge hits. The floor matters."
				},
				{
					name: "Stonesplit Attack",
					target: "Arsenal",
					detail: "After the rates, with the arsenal on Stonesplit."
				}
			],
			loop: "Deflect into Finding Spring. Spend one bar of Blade Momentum. Leave. Do not hold Throat-Piercing stacks against a person. Do not charge Phalanxbane in a duel unless they are already stunned and the bar will finish. Invigorated Warrior is optional and dangerous, because the first hit you take turns it against you."
		},
		group: {
			inner: [
				ARTS[18].signature,
				ARTS[19].signature,
				{
					name: "Steadfast Devotion",
					tag: "Crit",
					cited: true,
					detail: "Back on, with Throat-Piercing, when the fight is long enough that stacks survive. That is a boss, or a group fight where you are not the focus."
				},
				chant
			],
			offense: shattered,
			defense: {
				name: "Obsidian",
				where: "Armor",
				bonus: "Named on the PvE Strength sheet, with Eaglerise as the alternative. Use it when you are the damage, not the target. Agile Steps remains the duel chest."
			},
			gearNote: "Charged-skill damage on the chest is the Phalanxbane roll. Combo damage is the Snowparting roll. Match the roll to the weapon you are actually using.",
			note: "This group row is the sustained damage sheet. If the group fight is still a duel with extra people hitting you, stay on the arena row. Throat-Piercing will not stack."
		}
	},
	{
		ids: ["strategic-sword", "nameless-spear"],
		arenaRank: "T0.5",
		board: "A",
		mix: true,
		headline: "Umbra sword, Splendor spear",
		read: "The bleed sword with the mobile spear. OnKamii ranks it T0.5, above the designed Umbra pair. Game8's letter is A. Both weapons are still Bellstrike.",
		arsenal: "Bellstrike",
		arsenalWhy: "Same style. Do not switch the arsenal to General.",
		source: "Rank from the version 2.2 comparison. Inner ways are the cores of each weapon, not a single mixed bible.",
		arena: {
			inner: [
				ARTS[2].signature,
				ARTS[1].signature,
				chant,
				ARTS[2].second
			],
			mystic: [
				{
					name: "Serene Breeze",
					tag: "Break",
					cited: true,
					detail: "From the Umbra PvP mystic row. The mix does not have its own mystic sheet."
				},
				{
					name: "Cloud Steps",
					tag: "Gap",
					cited: true,
					detail: "Umbra's gap tool, and the spear already wants to move."
				},
				{
					name: "Meridian Touch",
					tag: "Lock",
					cited: true,
					detail: "Holds a target still long enough for Horizon's bleed to matter."
				},
				{
					name: "Leaping Toad",
					tag: "Arena",
					cited: true,
					detail: "The fourth Umbra PvP name."
				}
			],
			offense: hawkwing,
			defense: calmwaters,
			gearNote: "Hawkwing, because the sword half is an affinity and bleed loop. Calmwaters, because the spear half spends the fight dodging. Neither set was printed on a mixed-pair page.",
			stats: [
				{
					name: "Precision Rate",
					target: "High",
					detail: "The spear and the bleed both need the hit."
				},
				{
					name: "Affinity Rate",
					target: "Feed Hawkwing",
					detail: "Do not cap-chase the way pure Splendor does unless Insightful Strike is socketed. It is not, on this row."
				},
				{
					name: "Min Physical Attack",
					target: "With max",
					detail: "Spear chip plus bleed ticks."
				},
				{
					name: "Max Bellstrike Attack",
					target: "Arsenal",
					detail: "The mix stays Bellstrike. This stat works."
				}
			],
			loop: "Horizon follow-up to apply bleed, spear to move and to cash a target that is already tagged, back to the sword before endurance dies. Mountain's Might is why the spear can stay in the rotation.",
			note: "Blended from the two weapons' own cores. There is no single published inner-way card for the mix."
		}
	},
	{
		ids: ["nameless-sword", "infernal-twinblades"],
		arenaRank: "T0",
		board: "Mix",
		mix: true,
		headline: "Two cores, no shared arsenal",
		read: "OnKamii ranks Nameless Sword with Infernal Twinblades at T0. They are different styles. The arsenal goes General, and each Inner Way only sings on its own weapon.",
		arsenal: "General",
		arsenalWhy: "Bellstrike and Bamboocut do not share an attack type. General raises minimum and maximum physical attack for both. A Bellstrike or Bamboocut arsenal would leave one weapon unboosted.",
		source: "The T0 call is OnKamii's. The inner-way row is a blend. No mixed bible was published in the pages we used.",
		arena: {
			inner: [
				ARTS[4].signature,
				ARTS[0].signature,
				chant,
				evasive
			],
			mystic: [
				{
					name: "Serene Breeze",
					tag: "Break",
					cited: false,
					detail: "On both weapons' 1v1 lists separately. The mix itself has no mystic card."
				},
				{
					name: "Talon Strike",
					tag: "Punish",
					cited: false,
					detail: "Same. Both duel rows name it."
				},
				{
					name: "Cloud Steps",
					tag: "Gap",
					cited: false,
					detail: "Splendor's gap tool. Wind prefers Ghostly Steps when the blades are what you are leaving with."
				},
				{
					name: "Ghostly Steps",
					tag: "Leave",
					cited: true,
					detail: "Wind's published disengage. Keep it if the twinblades are the weapon that gets you in trouble."
				}
			],
			offense: swallow,
			defense: calmwaters,
			gearNote: "Swallowcall matches the twinblade light-attack plan. The sword would rather have Jadeware. You cannot wear both 4-pieces. Pick the weapon you spend more time on, and say so in the chest roll.",
			stats: [
				{
					name: "Precision Rate",
					target: "Near 100%",
					detail: "Wind's number. The sword can live lower on a pure affinity build. This mix is not that build."
				},
				{
					name: "Critical Rate",
					target: "Around 70%",
					detail: "Wind's Swallowcall band. Do not chase Splendor's affinity cap at the same time."
				},
				{
					name: "Min Physical Attack",
					target: "Then max",
					detail: "General arsenal raises both. This mix wants that, because there is no shared style attack."
				},
				{
					name: "Affinity Rate",
					target: "Modest",
					detail: "Enough for Sword Morph's world, not a 40% project. Echoes of Oblivion is not an affinity tome."
				}
			],
			loop: "Twinblades for the pressure, sword when Qi Shield is up and the charged flurry will land, dodge out instead of parrying yourself into a Wind punish. If you catch yourself playing only one weapon, you built the wrong pair.",
			note: "Blended desk. The rank is cited. The socket order is our join of the two cores."
		}
	},
	{
		ids: ["nameless-spear", "heavenwill-gauntlets"],
		arenaRank: "Top mix",
		board: "Mix",
		mix: true,
		headline: "The spear sets the table, the gauntlet takes it",
		read: "OnKamii has called Nameless Spear with Heavenwill Gauntlets his strongest pair. They do not share a style. General arsenal. Each core only works on its own weapon.",
		arsenal: "General",
		arsenalWhy: "Bellstrike spear, Bamboocut gauntlets. General is the arsenal that boosts both. A Bamboocut arsenal would feed the gauntlet talent and starve the spear.",
		source: "The ranking call is OnKamii's, from the version 2.2 tier comparison. Sockets are the two signatures plus the usual duel flex. Not a published card.",
		arena: {
			inner: [
				ARTS[8].signature,
				ARTS[1].signature,
				chant,
				evasive
			],
			mystic: [
				{
					name: "Cloud Steps",
					tag: "Staple",
					cited: false,
					detail: "The mix has no mystic card. You need a way to turn the spear poke into gauntlet range."
				},
				{
					name: "Serene Breeze",
					tag: "Staple",
					cited: false,
					detail: "Shared break."
				},
				{
					name: "Talon Strike",
					tag: "Staple",
					cited: false,
					detail: "The punish once you are in."
				},
				{
					name: "Leaping Toad",
					tag: "Staple",
					cited: false,
					detail: "Arena mobility while the gauntlet cooldown thinks."
				}
			],
			offense: swallow,
			defense: calmwaters,
			gearNote: "No set was named for this mix. Swallowcall fits spear lights and a gauntlet cash-out into low Qi. If your Heaven's Will procs are affinity, Hawkwing is the other honest weapon set. Say which weapon is the main before you craft.",
			stats: [
				{
					name: "Precision Rate",
					target: "High",
					detail: "The spear is a poke. A poke that misses does not set the gauntlet up."
				},
				{
					name: "Min Physical Attack",
					target: "Then max",
					detail: "General arsenal. Both weapons use physical attack, not a shared style attack."
				},
				{
					name: "Critical Rate",
					target: "On the cash-out",
					detail: "The gauntlet hit is the one that should crit. The spear can live without a crit-first build."
				},
				{
					name: "Max HP",
					target: "Enough to survive your own engage",
					detail: "You are walking into gauntlet range on purpose."
				}
			],
			loop: "Spear poke and Qiankun's Lock to create the step-in. Gauntlets spend Heaven's Will. Leave before you are the one being cashed out. Mountain's Might keeps the spear from going dry between engages.",
			note: "Blended desk. Rank cited, sockets joined."
		}
	}
];
var byId = new Map(ARTS.map((art) => [art.id, art]));
function getArt(id) {
	const art = byId.get(id);
	if (!art) throw new Error(`Unknown martial art: ${id}`);
	return art;
}
function suggestionsFor(id) {
	return suggest[id] ?? [];
}
function designedPartner(id) {
	return suggestionsFor(id)[0]?.id ?? id;
}
function findDuo(a, b) {
	return DUOS.find((duo) => duo.ids[0] === a && duo.ids[1] === b || duo.ids[0] === b && duo.ids[1] === a);
}
function pickMode(duo, mode) {
	if (mode === "arena" || !duo.group) return {
		...duo.arena,
		note: mode === "group" ? duo.sameNote ?? duo.group?.note ?? "No separate group sheet. This is the 1v1 desk." : duo.arena.note
	};
	const group = duo.group;
	return {
		inner: group.inner ?? duo.arena.inner,
		mystic: group.mystic ?? duo.arena.mystic,
		offense: group.offense ?? duo.arena.offense,
		defense: group.defense ?? duo.arena.defense,
		gearNote: group.gearNote ?? duo.arena.gearNote,
		stats: group.stats ?? duo.arena.stats,
		loop: group.loop ?? duo.arena.loop,
		note: group.note ?? duo.arena.note
	};
}
function hybrid(primary, partner, mode) {
	const same = primary.style === partner.style;
	const healer = primary.path.includes("Deluge") || partner.path.includes("Deluge");
	const flex = healer ? ARTS[14].second : mode === "arena" ? evasive : fury;
	const inner = [
		primary.signature,
		same ? primary.second : partner.signature,
		chant,
		flex
	];
	const seen = /* @__PURE__ */ new Set();
	const unique = inner.filter((slot) => {
		if (seen.has(slot.name)) return false;
		seen.add(slot.name);
		return true;
	});
	const fillers = [
		evasive,
		fury,
		leech
	];
	for (const filler of fillers) {
		if (unique.length >= 4) break;
		if (unique.some((slot) => slot.name === filler.name)) continue;
		unique.push(filler);
	}
	return {
		primary,
		partner,
		pairLabel: "Off-path blend",
		mix: true,
		offPath: true,
		arenaRank: "—",
		board: "—",
		headline: `${primary.name} lead, ${partner.name} in the other hand`,
		read: "No published 1v1 sheet matched this duo. The desk keeps each weapon's signature Inner Way, uses the shared arena kit, and does not invent a tier.",
		arsenal: same ? primary.style : "General",
		arsenalWhy: same ? `Both weapons are ${primary.style}, so that arsenal still raises both.` : `${primary.style} and ${partner.style} do not share an attack type. General raises minimum and maximum physical attack for both. A single-style arsenal would leave one weapon behind.`,
		source: "Generated from the two signature tomes. Not a ranked sheet.",
		modeNote: mode === "group" ? "Group flex is Fury Harvest so mystic arts stay up in a longer fight." : "Arena flex is Evasive Charge, and only if you perfect-dodge. Otherwise swap it for Vital Leech.",
		inner: unique.slice(0, 4),
		mystic: [
			{
				name: "Serene Breeze",
				tag: "Staple",
				cited: false,
				detail: "The break almost every cited 1v1 row already uses."
			},
			{
				name: "Cloud Steps",
				tag: "Staple",
				cited: false,
				detail: "The gap tool. Replace it with Ghostly Steps if the weapon that gets you killed is a twinblade."
			},
			{
				name: "Talon Strike",
				tag: "Staple",
				cited: false,
				detail: "The punish, from the melee duel rows."
			},
			healer ? {
				name: "Free Morph",
				tag: "Leave",
				cited: true,
				detail: "From the Deluge PvP list. A healer mix that cannot leave is a healer who dies."
			} : {
				name: "Leaping Toad",
				tag: "Staple",
				cited: false,
				detail: "Arena mobility while your martial skills think."
			}
		],
		offense: same && primary.style === "Bellstrike" ? hawkwing : swallow,
		defense: healer ? rainwhisper : calmwaters,
		gearNote: "Off-path sets are a fit, not a citation. Hawkwing if the lead weapon procs affinity. Swallowcall if it is light attacks. Calmwaters if the duel is dodges. Change the set when you change which weapon is the lead.",
		stats: [
			{
				name: "Precision Rate",
				target: "High",
				detail: "The one stat that is never the wrong first question on a mixed pair."
			},
			{
				name: same ? `Max ${primary.style} Attack` : "Min Physical Attack",
				target: same ? "Arsenal" : "Then max",
				detail: same ? "Shared style, so the style attack is real." : "General arsenal. Raise the floor and the ceiling of physical attack."
			},
			{
				name: "Critical Rate",
				target: "After precision",
				detail: "Do not buy it by missing."
			},
			{
				name: "Max HP",
				target: "Enough to finish the engage",
				detail: "Mixed pairs eat a hit they did not build a shield for."
			}
		],
		loop: `Open on ${primary.name}. Use ${partner.name} for the tool ${primary.name} does not have, then back. If one weapon never leaves the sheath, drop it and take the path pair.`
	};
}
function resolveDesk(primaryId, partnerId, mode) {
	const primary = getArt(primaryId);
	const partner = getArt(partnerId === primaryId ? designedPartner(primaryId) : partnerId);
	const duo = findDuo(primary.id, partner.id);
	if (!duo) return hybrid(primary, partner, mode);
	const sheet = pickMode(duo, mode);
	return {
		primary,
		partner,
		pairLabel: suggestionsFor(primary.id).find((item) => item.id === partner.id)?.label ?? (duo.mix ? "Ranked mix" : "Path pair"),
		mix: duo.mix,
		offPath: false,
		arenaRank: duo.arenaRank,
		board: duo.board,
		headline: duo.headline,
		read: duo.read,
		arsenal: duo.arsenal,
		arsenalWhy: duo.arsenalWhy,
		source: duo.source,
		modeNote: sheet.note ?? null,
		inner: sheet.inner,
		mystic: sheet.mystic,
		offense: sheet.offense,
		defense: sheet.defense,
		gearNote: sheet.gearNote,
		stats: sheet.stats,
		loop: sheet.loop
	};
}
function deskText(view, mode) {
	return [
		`Path Ledger · ${mode === "arena" ? "1v1 Arena" : "Group fight"}`,
		`${view.primary.name} + ${view.partner.name}`,
		`${view.primary.path} · ${view.pairLabel} · ${view.arenaRank}`,
		"",
		view.headline,
		view.read,
		"",
		"Inner Ways",
		...view.inner.map((slot, index) => `${index + 1}. ${slot.name} — ${slot.detail}`),
		"",
		"Mystic Arts",
		...view.mystic.map((slot) => `- ${slot.name} (${slot.cited ? "guide-named" : "arena staple"}) — ${slot.detail}`),
		"",
		"Items",
		`Offense: ${view.offense.name} (${view.offense.where}). ${view.offense.bonus}`,
		`Defense: ${view.defense.name} (${view.defense.where}). ${view.defense.bonus}`,
		view.gearNote,
		"",
		"PvP attributes",
		...view.stats.map((stat, index) => `${index + 1}. ${stat.name} — ${stat.target}. ${stat.detail}`),
		"",
		`Arsenal: ${view.arsenal}. ${view.arsenalWhy}`,
		"",
		view.loop,
		"",
		view.source
	].join("\n");
}
var STORAGE_KEY = "path-ledger-v1";
function loadSaved() {
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return null;
		const parsed = JSON.parse(raw);
		if (!parsed.primaryId || !parsed.partnerId || !parsed.mode) return null;
		return {
			primaryId: parsed.primaryId,
			partnerId: parsed.partnerId,
			mode: parsed.mode === "group" ? "group" : "arena",
			kind: parsed.kind ?? "All"
		};
	} catch {
		return null;
	}
}
function LedgerApp() {
	const [kind, setKind] = (0, import_react.useState)("Blade");
	const [query, setQuery] = (0, import_react.useState)("");
	const [primaryId, setPrimaryId] = (0, import_react.useState)("snowparting-blade");
	const [partnerId, setPartnerId] = (0, import_react.useState)("phalanxbane-blade");
	const [mode, setMode] = (0, import_react.useState)("arena");
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [more, setMore] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const saved = loadSaved();
		if (!saved) return;
		if (!ARTS.some((art) => art.id === saved.primaryId)) return;
		if (!ARTS.some((art) => art.id === saved.partnerId)) return;
		setPrimaryId(saved.primaryId);
		setPartnerId(saved.partnerId);
		setMode(saved.mode);
		setKind(saved.kind);
	}, []);
	(0, import_react.useEffect)(() => {
		const payload = {
			primaryId,
			partnerId,
			mode,
			kind
		};
		localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
	}, [
		primaryId,
		partnerId,
		mode,
		kind
	]);
	const arts = (0, import_react.useMemo)(() => {
		const q = query.trim().toLowerCase();
		return ARTS.filter((art) => {
			if (kind !== "All" && art.kind !== kind) return false;
			if (!q) return true;
			return art.name.toLowerCase().includes(q) || art.path.toLowerCase().includes(q) || art.kind.toLowerCase().includes(q);
		});
	}, [kind, query]);
	const view = resolveDesk(primaryId, partnerId, mode);
	const suggestions = suggestionsFor(view.primary.id);
	const otherPartners = ARTS.filter((art) => art.id !== view.primary.id && !suggestions.some((item) => item.id === art.id));
	function choosePrimary(id) {
		setPrimaryId(id);
		setPartnerId(designedPartner(id));
		setMore(false);
		setCopied(false);
	}
	async function copyDesk() {
		const text = deskText(view, mode);
		try {
			await navigator.clipboard.writeText(text);
		} catch {
			const area = document.createElement("textarea");
			area.value = text;
			area.setAttribute("readonly", "true");
			document.body.appendChild(area);
			area.select();
			document.execCommand("copy");
			area.remove();
		}
		setCopied(true);
	}
	const seal = /^T\d(\.5)?$/.test(view.arenaRank);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto min-h-screen w-full max-w-6xl px-4 pb-12 pt-5 sm:px-6 lg:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-5 flex items-end justify-between gap-4 border-b border-line pb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-widest text-cinnabar uppercase",
					children: "Where Winds Meet"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 font-display text-4xl leading-none font-medium text-paper italic",
					children: "Path Ledger"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "hidden max-w-xs text-right text-sm leading-snug text-dim sm:block",
					children: "Main weapon, then the art in the other hand."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid items-start gap-6 lg:grid-cols-[18rem_minmax(0,1fr)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "order-2 grid gap-4 lg:order-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "sr-only",
							children: "Search martial arts"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: query,
							onChange: (event) => setQuery(event.target.value),
							placeholder: "Search a weapon or path",
							className: "w-full rounded-xl border border-line bg-panel px-3 py-3 text-base text-paper placeholder:text-dim"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-3 gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KindChip, {
								active: kind === "All",
								onClick: () => setKind("All"),
								label: "All"
							}), KINDS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KindChip, {
								active: kind === item,
								onClick: () => setKind(item),
								label: item
							}, item))]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid max-h-72 gap-1.5 overflow-y-auto",
							children: arts.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "py-4 text-sm text-dim",
								children: "Nothing matches."
							}) : arts.map((art) => {
								const selected = art.id === view.primary.id;
								const rank = suggestionsFor(art.id)[0]?.rank ?? "";
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => choosePrimary(art.id),
									"aria-pressed": selected,
									className: "flex min-h-11 items-center justify-between gap-3 rounded-xl border px-3 py-2 text-left transition-colors " + (selected ? "border-cinnabar bg-panel" : "border-line bg-lacquer hover:border-dim"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "min-w-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block truncate text-sm font-medium text-paper",
											children: art.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block truncate text-xs text-dim",
											children: art.path
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "shrink-0 text-xs text-cinnabar",
										children: rank
									})]
								}, art.id);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-2 flex items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-xs font-medium tracking-widest text-dim uppercase",
								children: "Partner"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex rounded-full border border-line p-0.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeButton, {
									active: mode === "arena",
									onClick: () => {
										setMode("arena");
										setCopied(false);
									},
									children: "1v1"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModeButton, {
									active: mode === "group",
									onClick: () => {
										setMode("group");
										setCopied(false);
									},
									children: "Group"
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-1.5",
							children: [
								suggestions.map((item) => {
									const art = ARTS.find((entry) => entry.id === item.id);
									if (!art) return null;
									const selected = art.id === view.partner.id;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										"aria-pressed": selected,
										onClick: () => {
											setPartnerId(item.id);
											setCopied(false);
										},
										className: "flex min-h-11 items-center justify-between gap-3 rounded-xl border px-3 py-2 text-left text-sm transition-colors " + (selected ? "border-cinnabar bg-cinnabar text-paper" : "border-line bg-lacquer text-paper hover:border-dim"),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "min-w-0 truncate font-medium",
											children: art.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "shrink-0 text-xs opacity-80",
											children: item.rank
										})]
									}, item.id);
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setMore((value) => !value),
									className: "min-h-11 rounded-xl border border-line px-3 text-left text-sm text-dim",
									children: more ? "Hide other arts" : "Any other art"
								}),
								more ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid max-h-48 gap-1.5 overflow-y-auto",
									children: otherPartners.map((art) => {
										const selected = art.id === view.partner.id;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											"aria-pressed": selected,
											onClick: () => {
												setPartnerId(art.id);
												setCopied(false);
											},
											className: "min-h-11 rounded-xl border px-3 text-left text-sm " + (selected ? "border-cinnabar bg-cinnabar text-paper" : "border-line text-paper"),
											children: art.name
										}, art.id);
									})
								}) : null
							]
						})] })
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "relative order-1 overflow-hidden rounded-2xl bg-paper text-ink lg:order-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border-b border-rule px-5 py-5 sm:px-7",
							children: [seal ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute top-4 right-4 grid size-14 place-items-center rounded-full border-2 border-cinnabar text-cinnabar",
								"aria-hidden": "true",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-lg leading-none",
									children: view.arenaRank
								})
							}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: seal ? "pr-16" : "",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs font-medium tracking-widest text-cinnabar uppercase",
										children: [
											view.pairLabel,
											view.board !== "—" ? ` · Game8 ${view.board}` : "",
											!seal && view.arenaRank !== "—" ? ` · ${view.arenaRank}` : ""
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "mt-2 font-display text-4xl leading-none font-medium",
										children: view.primary.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 font-display text-xl text-ink-soft italic",
										children: ["with ", view.partner.name]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-3 max-w-2xl text-sm leading-relaxed text-ink-soft",
										children: [
											view.primary.path,
											view.primary.path !== view.partner.path ? ` · ${view.partner.path}` : "",
											". ",
											view.headline,
											".",
											" ",
											view.read
										]
									})
								]
							})]
						}),
						view.modeNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "border-b border-rule bg-paper-deep px-5 py-3 text-sm leading-relaxed text-ink-soft sm:px-7",
							children: view.modeNote
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-6 px-5 py-5 sm:px-7 lg:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
									kicker: "Inner Ways",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
										className: "grid gap-2",
										children: view.inner.map((slot, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: "rounded-xl bg-paper-deep px-3 py-2.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-baseline justify-between gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
													className: "text-sm font-medium",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "mr-2 text-cinnabar",
														children: index + 1
													}), slot.name]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "shrink-0 text-xs tracking-wide text-ink-soft uppercase",
													children: slot.tag
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 text-sm leading-relaxed text-ink-soft",
												children: slot.detail
											})]
										}, slot.name))
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
									kicker: "Mystic Arts",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "grid gap-2",
										children: view.mystic.map((slot) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: "rounded-xl bg-paper-deep px-3 py-2.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-baseline justify-between gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
													className: "text-sm font-medium",
													children: slot.name
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "shrink-0 text-xs tracking-wide text-ink-soft uppercase",
													children: slot.cited ? slot.tag : "Staple"
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 text-sm leading-relaxed text-ink-soft",
												children: slot.detail
											})]
										}, slot.name))
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
									kicker: "Items",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SetCard, {
												label: "Offense",
												name: view.offense.name,
												where: view.offense.where,
												bonus: view.offense.bonus
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SetCard, {
												label: "Defense",
												name: view.defense.name,
												where: view.defense.where,
												bonus: view.defense.bonus
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm leading-relaxed text-ink-soft",
												children: view.gearNote
											})
										]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
									kicker: "PvP attributes",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
										className: "grid gap-3",
										children: view.stats.map((stat, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: "grid grid-cols-[1.5rem_minmax(0,1fr)] gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-sm font-medium text-cinnabar",
												children: index + 1
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex flex-wrap items-baseline justify-between gap-x-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
													className: "text-sm font-medium",
													children: stat.name
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs text-cinnabar",
													children: stat.target
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-0.5 text-sm leading-relaxed text-ink-soft",
												children: stat.detail
											})] })]
										}, stat.name))
									})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 border-t border-rule px-5 py-4 sm:px-7 lg:grid-cols-[8rem_minmax(0,1fr)]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium tracking-widest text-cinnabar uppercase",
								children: "Arsenal"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 font-display text-2xl leading-none",
								children: view.arsenal
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm leading-relaxed text-ink-soft",
								children: view.arsenalWhy
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-relaxed",
								children: view.loop
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center justify-between gap-3 border-t border-rule px-5 py-3 sm:px-7",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "max-w-xl text-xs leading-relaxed text-ink-soft",
								children: view.source
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: copyDesk,
								className: "inline-flex min-h-11 shrink-0 items-center gap-2 rounded-full bg-ink px-4 text-sm text-paper",
								children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
									className: "size-4",
									"aria-hidden": "true"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {
									className: "size-4",
									"aria-hidden": "true"
								}), copied ? "Copied" : "Copy this desk"]
							})]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-xs leading-relaxed text-dim",
				children: "Public Global 2.2 sheets, October 2026. Patch numbers move. Silkbind Wing is left off until it has a ranked sheet."
			})
		]
	});
}
function KindChip({ active, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": active,
		onClick,
		className: "min-h-11 rounded-lg px-1 text-xs " + (active ? "bg-cinnabar text-paper" : "bg-panel text-dim"),
		children: label
	});
}
function ModeButton({ active, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": active,
		onClick,
		className: "min-h-11 rounded-full px-3 text-xs font-medium " + (active ? "bg-paper text-ink" : "text-dim"),
		children
	});
}
function Section({ kicker, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
		className: "mb-2 text-xs font-medium tracking-widest text-cinnabar uppercase",
		children: kicker
	}), children] });
}
function SetCard({ label, name, where, bonus }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-paper-deep px-3 py-2.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-wide text-ink-soft uppercase",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-sm font-medium",
				children: name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-ink-soft",
				children: where
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm leading-relaxed text-ink-soft",
				children: bonus
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LedgerApp, {});
}
//#endregion
export { Home as component };
