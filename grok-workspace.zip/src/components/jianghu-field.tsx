import { useEffect } from "react";

const FIGHTERS = [
  { src: "/jianghu/sword.jpg?v=3d", x: "-4%", start: "4vh", speed: 0.42, w: "min(62vw, 460px)", o: 0.92, turn: "-16deg", z: "40px" },
  { src: "/jianghu/umbrella.jpg?v=3d", x: "58%", start: "14vh", speed: 0.7, w: "min(56vw, 420px)", o: 0.88, turn: "18deg", z: "80px" },
  { src: "/jianghu/spear.jpg?v=3d", x: "-8%", start: "88vh", speed: 0.52, w: "min(60vw, 440px)", o: 0.9, turn: "-10deg", z: "20px" },
  { src: "/jianghu/blades.jpg?v=3d", x: "54%", start: "124vh", speed: 0.84, w: "min(54vw, 400px)", o: 0.9, turn: "14deg", z: "110px" },
  { src: "/jianghu/sword.jpg?v=3d", x: "6%", start: "206vh", speed: 0.48, w: "min(50vw, 380px)", o: 0.82, turn: "8deg", z: "60px" },
  { src: "/jianghu/umbrella.jpg?v=3d", x: "62%", start: "246vh", speed: 0.64, w: "min(52vw, 390px)", o: 0.8, turn: "-12deg", z: "30px" },
];

export function JianghuField() {
  useEffect(() => {
    const root = document.documentElement;
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const apply = () => {
      root.style.setProperty("--scroll", reduce ? "0" : String(window.scrollY));
    };
    apply();
    if (reduce) return;
    window.addEventListener("scroll", apply, { passive: true });
    return () => window.removeEventListener("scroll", apply);
  }, []);

  return (
    <div className="jianghu-field" aria-hidden="true">
      <img className="jianghu-land" src="/jianghu/mountains.jpg" alt="" />
      {FIGHTERS.map((fighter, index) => (
        <img
          key={index}
          className="jianghu-fighter"
          src={fighter.src}
          alt=""
          style={{
            left: fighter.x,
            ["--start" as string]: fighter.start,
            ["--speed" as string]: String(fighter.speed),
            ["--w" as string]: fighter.w,
            ["--o" as string]: String(fighter.o),
            ["--turn" as string]: fighter.turn,
            ["--z" as string]: fighter.z,
          }}
        />
      ))}
    </div>
  );
}
