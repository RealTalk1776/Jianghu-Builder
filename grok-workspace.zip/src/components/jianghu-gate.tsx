import { useEffect, useState } from "react";

function playCreak() {
  const audio = new Audio("/jianghu/creak.mp3?v=door");
  audio.volume = 0.9;
  void audio.play().catch(() => {});
}

const WISPS = [
  { left: "2%", bottom: "0%", delay: "0s", size: "34vw", rise: "-78vh" },
  { left: "16%", bottom: "8%", delay: "0.06s", size: "40vw", rise: "-90vh" },
  { left: "32%", bottom: "0%", delay: "0.12s", size: "36vw", rise: "-84vh" },
  { left: "48%", bottom: "12%", delay: "0.04s", size: "46vw", rise: "-96vh" },
  { left: "64%", bottom: "0%", delay: "0.16s", size: "38vw", rise: "-80vh" },
  { left: "80%", bottom: "6%", delay: "0.1s", size: "42vw", rise: "-92vh" },
  { left: "96%", bottom: "0%", delay: "0.18s", size: "34vw", rise: "-76vh" },
  { left: "8%", bottom: "28%", delay: "0.28s", size: "30vw", rise: "-70vh" },
  { left: "38%", bottom: "22%", delay: "0.34s", size: "36vw", rise: "-74vh" },
  { left: "70%", bottom: "30%", delay: "0.3s", size: "32vw", rise: "-68vh" },
  { left: "90%", bottom: "24%", delay: "0.4s", size: "28vw", rise: "-64vh" },
];

export function JianghuGate({ onEnter }: { onEnter: () => void }) {
  const [opening, setOpening] = useState(false);

  useEffect(() => {
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previous;
    };
  }, []);

  function press() {
    if (opening) return;
    playCreak();
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      onEnter();
      return;
    }
    setOpening(true);
  }

  return (
    <div
      className={opening ? "gate is-open" : "gate"}
      role="dialog"
      aria-modal="true"
      aria-label="Welcome to The Jianghu"
      onAnimationEnd={(event) => {
        if (event.animationName === "gate-fade") onEnter();
      }}
    >
      <div className="door door-left" aria-hidden="true">
        <span className="door-studs" />
        <span className="knocker" />
      </div>
      <div className="door door-right" aria-hidden="true">
        <span className="door-studs" />
        <span className="knocker" />
      </div>
      <div className="smoke" aria-hidden="true">
        <span className="fog" />
        {WISPS.map((wisp) => (
          <span
            key={wisp.left + wisp.delay}
            className="wisp"
            style={{
              left: wisp.left,
              bottom: wisp.bottom,
              animationDelay: wisp.delay,
              ["--wisp" as string]: wisp.size,
              ["--rise" as string]: wisp.rise,
            }}
          />
        ))}
      </div>
      <button type="button" className="gate-press" onClick={press} disabled={opening}>
        <span className="gate-kicker">Jianghu Builder</span>
        <span className="gate-title">Welcome to The Jianghu</span>
        <span className="gate-hint">Press the door</span>
      </button>
      <div className="gate-out" />
    </div>
  );
}
