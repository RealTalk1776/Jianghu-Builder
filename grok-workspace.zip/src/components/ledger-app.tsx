import { useEffect, useLayoutEffect, useMemo, useState, type ReactNode } from "react";
import { Check, Copy } from "lucide-react";
import {
  ARTS,
  KINDS,
  type Mode,
  type WeaponKind,
  deskText,
  resolveDesk,
  suggestionsFor,
} from "@/lib/ledger";
import { applySeason, seasonAt } from "@/lib/seasons";
import { JianghuField } from "@/components/jianghu-field";

export function LedgerApp() {
  const [season, setSeason] = useState(() => seasonAt());

  useLayoutEffect(() => {
    applySeason(season);
  }, [season]);

  useEffect(() => {
    const tick = () => setSeason(seasonAt());
    const id = window.setInterval(tick, 60_000);
    document.addEventListener("visibilitychange", tick);
    return () => {
      window.clearInterval(id);
      document.removeEventListener("visibilitychange", tick);
    };
  }, []);
  const [kind, setKind] = useState<WeaponKind | "All">("All");
  const [query, setQuery] = useState("");
  const [primaryId, setPrimaryId] = useState<string | null>(null);
  const [partnerId, setPartnerId] = useState<string | null>(null);
  const [mode, setMode] = useState<Mode>("arena");
  const [copied, setCopied] = useState(false);
  const [more, setMore] = useState(false);

  const arts = useMemo(() => {
    const q = query.trim().toLowerCase();
    return ARTS.filter((art) => {
      if (kind !== "All" && art.kind !== kind) return false;
      if (!q) return true;
      return (
        art.name.toLowerCase().includes(q) ||
        art.path.toLowerCase().includes(q) ||
        art.kind.toLowerCase().includes(q)
      );
    });
  }, [kind, query]);

  const view =
    primaryId && partnerId ? resolveDesk(primaryId, partnerId, mode) : null;
  const suggestions = primaryId ? suggestionsFor(primaryId) : [];
  const otherPartners = primaryId
    ? ARTS.filter((art) => art.id !== primaryId && !suggestions.some((item) => item.id === art.id))
    : [];

  function choosePrimary(id: string) {
    setPrimaryId(id);
    setPartnerId(null);
    setMore(false);
    setCopied(false);
  }

  async function copyDesk() {
    if (!view) return;
    const text = deskText(view, mode);
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const area = document.createElement("textarea");
      area.value = text;
      area.setAttribute("readonly", "true");
      document.body.appendChild(area);
      area.select();
      document.execCommand("copy");
      area.remove();
    }
    setCopied(true);
  }

  const rankLine = !view
    ? ""
    : view.offPath
    ? `${mode === "arena" ? "1v1 Arena" : "Group fight"} · ${view.usage} of players · No published build`
    : [
        mode === "arena" ? "1v1 Arena" : "Group fight",
        view.arenaRank !== "—" ? view.arenaRank : null,
        `${view.usage} of players`,
      ]
        .filter(Boolean)
        .join(" · ");

  return (
    <>
      <JianghuField />
      <main className="relative z-10 mx-auto box-border min-h-screen w-full max-w-6xl overflow-x-hidden pt-5 pb-10 pl-[max(1.25rem,env(safe-area-inset-left))] pr-[max(1.25rem,env(safe-area-inset-right))] sm:pr-6 sm:pl-6 lg:pr-8 lg:pl-8">
      <header className="mb-4 flex items-end justify-between gap-4">
        <div>
          <p className="text-xs font-medium tracking-widest text-cinnabar uppercase">{season.label}</p>
          <h1 className="mt-1 max-w-full font-display text-4xl leading-none font-medium break-words text-paper italic">
            Jianghu Builder
          </h1>
        </div>
        <p className="hidden max-w-xs text-right text-sm leading-snug text-dim sm:block">
          Main weapon, then the art in the other hand.
        </p>
      </header>

      <div className="grid min-w-0 gap-6">
        <section className="grid min-w-0 gap-4">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
            <label className="min-w-0 flex-1">
              <span className="sr-only">Search martial arts</span>
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                placeholder="Search a weapon or path"
                className="w-full rounded-xl border border-line bg-panel px-3 py-3 text-base text-paper placeholder:text-dim"
              />
            </label>
            <div className="flex w-fit rounded-full border border-line p-0.5">
              <ModeButton
                active={mode === "arena"}
                onClick={() => {
                  setMode("arena");
                  setCopied(false);
                }}
              >
                1v1
              </ModeButton>
              <ModeButton
                active={mode === "group"}
                onClick={() => {
                  setMode("group");
                  setCopied(false);
                }}
              >
                Group
              </ModeButton>
            </div>
          </div>

          <div className="flex max-w-full flex-wrap gap-1.5">
            <KindChip active={kind === "All"} onClick={() => setKind("All")} label="All" />
            {KINDS.map((item) => (
              <KindChip
                key={item}
                active={kind === item}
                onClick={() => setKind(item)}
                label={item === "Blade" ? "Heng Blade" : item === "Drum" ? "Waist Drum" : item}
              />
            ))}
          </div>

          <div className="min-w-0">
            <h2 className="mb-2 text-xs font-medium tracking-widest text-dim uppercase">Weapon</h2>
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-3">
              {arts.length === 0 ? (
                <p className="col-span-full py-3 text-sm text-dim">Nothing matches.</p>
              ) : (
                arts.map((art) => {
                  const selected = art.id === primaryId;
                  const rank = suggestionsFor(art.id)[0]?.rank ?? "";
                  return (
                    <button
                      key={art.id}
                      type="button"
                      onClick={() => choosePrimary(art.id)}
                      aria-pressed={selected}
                      className={
                        "flex min-h-11 min-w-0 flex-col justify-center rounded-xl border px-3 py-2 text-left transition-colors " +
                        (selected ? "border-cinnabar bg-panel" : "border-line bg-lacquer")
                      }
                    >
                      <span className="truncate text-sm font-medium text-paper">{art.name}</span>
                      <span className="truncate text-xs text-cinnabar">{rank}</span>
                    </button>
                  );
                })
              )}
            </div>
          </div>

          <div className="min-w-0">
            <h2 className="mb-2 text-xs font-medium tracking-widest text-dim uppercase">Martial art</h2>
            {primaryId ? (
            <>
            <div className="grid gap-2 sm:grid-cols-2">
              {suggestions.map((item) => {
                const art = ARTS.find((entry) => entry.id === item.id);
                if (!art) return null;
                const selected = art.id === partnerId;
                return (
                  <button
                    key={item.id}
                    type="button"
                    aria-pressed={selected}
                    onClick={() => {
                      setPartnerId(item.id);
                      setCopied(false);
                    }}
                    className={
                      "flex min-h-11 min-w-0 flex-col justify-center rounded-xl border px-3 py-2 text-left transition-colors " +
                      (selected ? "border-cinnabar bg-panel text-paper" : "border-line text-paper")
                    }
                  >
                    <span className="truncate text-sm font-medium">{art.name}</span>
                    <span className="truncate text-xs text-dim">
                      {item.label} · {item.rank}
                    </span>
                  </button>
                );
              })}
              <button
                type="button"
                onClick={() => setMore((value) => !value)}
                className="min-h-11 rounded-xl border border-line px-3 text-left text-sm text-dim"
              >
                {more ? "Hide other arts" : "Any other art"}
              </button>
            </div>
            {more ? (
              <div className="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-2">
                {otherPartners.map((art) => {
                  const selected = art.id === partnerId;
                  return (
                    <button
                      key={art.id}
                      type="button"
                      aria-pressed={selected}
                      onClick={() => {
                        setPartnerId(art.id);
                        setCopied(false);
                      }}
                      className={
                        "min-h-11 min-w-0 truncate rounded-xl border px-3 text-left text-sm text-paper " +
                        (selected ? "border-cinnabar bg-panel" : "border-line")
                      }
                    >
                      {art.name}
                    </button>
                  );
                })}
              </div>
            ) : null}
            </>
            ) : (
              <p className="text-sm leading-relaxed text-dim">Pick a weapon. The build stays closed until you choose the art in the other hand.</p>
            )}
          </div>
        </section>

        {view ? (
        <article className="min-w-0 overflow-hidden rounded-2xl bg-paper text-ink">
          <div className="border-b border-rule px-4 py-4 sm:px-6 sm:py-5">
            <div className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1">
              <p className="text-xs font-medium tracking-widest text-cinnabar uppercase">{view.pairLabel}</p>
              <p className="text-xs text-ink-soft">{rankLine}</p>
            </div>
            <h2 className="mt-2 font-display text-3xl leading-none font-medium break-words sm:text-4xl">
              {view.primary.name}
            </h2>
            <p className="mt-1 font-display text-xl text-ink-soft italic break-words">with {view.partner.name}</p>
            <p className="mt-3 text-sm leading-relaxed text-ink-soft">
              {view.primary.path}
              {view.primary.path !== view.partner.path ? ` · ${view.partner.path}` : ""}
            </p>
            <p className="mt-2 max-w-2xl text-sm leading-relaxed">{view.headline}</p>
            <p className="mt-1 max-w-2xl text-sm leading-relaxed text-ink-soft">{view.read}</p>
          </div>

          {view.modeNote ? (
            <p className="border-b border-rule px-4 py-3 text-sm leading-relaxed break-words text-ink-soft sm:px-6">
              {view.modeNote}
            </p>
          ) : null}

          <div className="grid min-w-0 gap-6 px-4 py-4 sm:px-6 sm:py-5 lg:grid-cols-2">
            <Section kicker="Inner Ways">
              <ol className="grid gap-3">
                {view.inner.map((slot, index) => (
                  <li key={slot.name}>
                    <div className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-0.5">
                      <h3 className="min-w-0 text-sm font-medium break-words">
                        <span className="mr-2 text-cinnabar">{index + 1}</span>
                        {slot.name}
                      </h3>
                      <span className="text-xs text-ink-soft uppercase">{slot.tag}</span>
                    </div>
                    <p className="mt-1 text-sm leading-relaxed text-ink-soft">{slot.detail}</p>
                  </li>
                ))}
              </ol>
            </Section>

            <Section kicker="Mystic Arts">
              <ul className="grid gap-3">
                {view.mystic.map((slot) => (
                  <li key={slot.name}>
                    <div className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-0.5">
                      <h3 className="min-w-0 text-sm font-medium break-words">{slot.name}</h3>
                      <span className="text-xs text-ink-soft uppercase">
                        {slot.cited ? slot.tag : "Staple"}
                      </span>
                    </div>
                    <p className="mt-1 text-sm leading-relaxed text-ink-soft">{slot.detail}</p>
                  </li>
                ))}
              </ul>
            </Section>

            <Section kicker="Items">
              <div className="grid gap-3">
                <SetCard label="Offense" name={view.offense.name} where={view.offense.where} bonus={view.offense.bonus} />
                <SetCard label="Defense" name={view.defense.name} where={view.defense.where} bonus={view.defense.bonus} />
                <p className="text-sm leading-relaxed text-ink-soft">{view.gearNote}</p>
              </div>
            </Section>

            <Section kicker="PvP attributes">
              <ol className="grid gap-3">
                {view.stats.map((stat, index) => (
                  <li key={stat.name}>
                    <div className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-0.5">
                      <h3 className="min-w-0 text-sm font-medium break-words">
                        <span className="mr-2 text-cinnabar">{index + 1}</span>
                        {stat.name}
                      </h3>
                      <span className="max-w-full text-xs break-words text-cinnabar">{stat.target}</span>
                    </div>
                    <p className="mt-1 text-sm leading-relaxed text-ink-soft">{stat.detail}</p>
                  </li>
                ))}
              </ol>
            </Section>
          </div>

          <div className="border-t border-rule px-4 py-4 sm:px-6">
            <div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
              <p className="text-xs font-medium tracking-widest text-cinnabar uppercase">Arsenal</p>
              <p className="font-display text-2xl leading-none break-words">{view.arsenal}</p>
            </div>
            <p className="mt-2 text-sm leading-relaxed text-ink-soft">{view.arsenalWhy}</p>
            <p className="mt-3 font-display text-4xl leading-none text-cinnabar">{view.usage}</p>
            <p className="mt-1 text-sm leading-relaxed text-ink-soft">
              of players in PvP have used this build
            </p>
            <p className="mt-2 text-sm leading-relaxed">{view.loop}</p>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-rule px-4 py-3 sm:px-6">
            <p className="min-w-0 flex-1 text-xs leading-relaxed text-ink-soft">{view.source}</p>
            <button
              type="button"
              onClick={copyDesk}
              className="inline-flex min-h-11 shrink-0 items-center gap-2 rounded-full bg-ink px-4 text-sm text-paper"
            >
              {copied ? <Check className="size-4" aria-hidden="true" /> : <Copy className="size-4" aria-hidden="true" />}
              {copied ? "Copied" : "Copy desk"}
            </button>
          </div>
        </article>
        ) : (
          <p className="text-sm leading-relaxed text-dim">
            {primaryId ? "Choose a martial art to open the build." : "The build stays closed until both hands are chosen."}
          </p>
        )}
      </div>

      <p className="mt-4 text-xs leading-relaxed text-dim">
        Public Global 2.2 sheets, October 2026. The percent is how often that pair shows up on the Sept 19 high-rank board, not a counted ladder. A pair with no published build is marked “How it could work.”
      </p>
    </main>
    </>
  );
}

function KindChip({
  active,
  label,
  onClick,
}: {
  active: boolean;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      aria-pressed={active}
      onClick={onClick}
      className={
        "min-h-11 max-w-full rounded-full px-3 text-xs " +
        (active ? "bg-cinnabar text-ink" : "bg-panel text-dim")
      }
    >
      {label}
    </button>
  );
}

function ModeButton({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: string;
}) {
  return (
    <button
      type="button"
      aria-pressed={active}
      onClick={onClick}
      className={
        "min-h-11 rounded-full px-3 text-xs font-medium " +
        (active ? "bg-paper text-ink" : "text-dim")
      }
    >
      {children}
    </button>
  );
}

function Section({ kicker, children }: { kicker: string; children: ReactNode }) {
  return (
    <section>
      <h3 className="mb-2 text-xs font-medium tracking-widest text-cinnabar uppercase">{kicker}</h3>
      {children}
    </section>
  );
}

function SetCard({
  label,
  name,
  where,
  bonus,
}: {
  label: string;
  name: string;
  where: string;
  bonus: string;
}) {
  return (
    <div>
      <p className="text-xs text-ink-soft uppercase">{label}</p>
      <h3 className="text-sm font-medium break-words">
        {name}
        <span className="font-normal text-ink-soft"> · {where}</span>
      </h3>
      <p className="mt-1 text-sm leading-relaxed text-ink-soft">{bonus}</p>
    </div>
  );
}
