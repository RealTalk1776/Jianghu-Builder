export type Mode = "arena" | "group";

export type WeaponKind =
  | "Sword"
  | "Spear"
  | "Blade"
  | "Twinblades"
  | "Fan"
  | "Drum"
  | "Umbrella"
  | "Rope Dart"
  | "Gauntlets";

export type Style = "Bellstrike" | "Stonesplit" | "Silkbind" | "Bamboocut";

export type Slot = {
  name: string;
  tag: string;
  detail: string;
  cited: boolean;
};

export type SetBonus = {
  name: string;
  where: string;
  bonus: string;
};

export type Stat = {
  name: string;
  target: string;
  detail: string;
};

export type Art = {
  id: string;
  name: string;
  kind: WeaponKind;
  path: string;
  style: Style;
  role: string;
  blurb: string;
  signature: Slot;
  second: Slot;
};

export type Suggestion = {
  id: string;
  label: "Path pair" | "Ranked mix";
  rank: string;
  board: string;
  why: string;
};

type ModeDesk = {
  inner: Slot[];
  mystic: Slot[];
  offense: SetBonus;
  defense: SetBonus;
  gearNote: string;
  stats: Stat[];
  loop: string;
  note?: string;
};

type Duo = {
  ids: [string, string];
  arenaRank: string;
  board: string;
  headline: string;
  read: string;
  arsenal: string;
  arsenalWhy: string;
  source: string;
  mix: boolean;
  arena: ModeDesk;
  group?: Partial<ModeDesk>;
  sameNote?: string;
};

function tome(name: string, tag: string, detail: string, cited = true): Slot {
  return { name, tag, detail, cited };
}

const chant = tome(
  "Morale Chant",
  "General",
  "About an 80% chance, on an attack or a heal, to gain a stack of Yi River. Each stack adds 1% physical damage and healing for 8 seconds. A flexible slot, not a reason to drop the Inner Way that actually changes your weapon.",
);

const evasive = tome(
  "Evasive Charge",
  "Arena",
  "A chance to refund endurance after a perfect dodge. Game8 slots it in 1v1 when you really dodge. It does nothing if you only deflect, block, or eat the hit.",
);

const fury = tome(
  "Fury Harvest",
  "Arena",
  "Attacks can restore Vitality. Worth a slot when Mystic Arts are the thing running dry. Skip it if you rarely spend Vitality.",
);

const leech = tome(
  "Vital Leech",
  "Execute",
  "An execution on an exhausted target heals you from the damage dealt. Real when fights end in exhaustion. Weak when nobody is allowed to sit in that window.",
);

export const KINDS: WeaponKind[] = [
  "Sword",
  "Spear",
  "Blade",
  "Twinblades",
  "Fan",
  "Drum",
  "Umbrella",
  "Rope Dart",
  "Gauntlets",
];

export const ARTS: Art[] = [
  {
    id: "nameless-sword",
    name: "Nameless Sword",
    kind: "Sword",
    path: "Bellstrike — Splendor",
    style: "Bellstrike",
    role: "Mobile damage",
    blurb: "Qi Shield into charged sword energy. The straightforward Bellstrike sword.",
    signature: tome(
      "Sword Morph",
      "Core",
      "While Qi Shield is up, a charged attack spends extra endurance and throws a flurry of sword energy. Fearless Lunge and the martial skill are the easy ways to raise the shield. Upgrade this first.",
    ),
    second: tome(
      "Battle Anthem",
      "Charged",
      "Raises charged-skill damage into bosses. Keep it when charges are the plan. It is a weak PvP slot, because the bonus is a boss mod.",
    ),
  },
  {
    id: "nameless-spear",
    name: "Nameless Spear",
    kind: "Spear",
    path: "Bellstrike — Splendor",
    style: "Bellstrike",
    role: "Poke and swap",
    blurb: "The spear half of Splendor. Endurance is the tax. Qiankun's Lock pays some of it back.",
    signature: tome(
      "Mountain's Might",
      "Core",
      "Improves the endurance refund on Qiankun's Lock. The spear spends endurance to move and to hit, so this is the slot that keeps the loop from stalling.",
    ),
    second: tome(
      "Wildfire Spark",
      "Endurance",
      "Refunds a cut of endurance when you attack. Pairs with Mountain's Might when the spear is the weapon that is actually moving.",
    ),
  },
  {
    id: "strategic-sword",
    name: "Strategic Sword",
    kind: "Sword",
    path: "Bellstrike — Umbra",
    style: "Bellstrike",
    role: "Bleed burst",
    blurb: "Single-target bleed and follow-up slashes. Higher ceiling in a duel than in a messy pull.",
    signature: tome(
      "Sword Horizon",
      "Core",
      "After a Strategic Sword martial skill, charged skill, or special, you can follow with the cross-slash. It applies bleed. It only functions on Strategic Sword.",
    ),
    second: tome(
      "Fivefold Bleed",
      "Bleed",
      "Hits can stack bleed to five. The fifth stack clears into piercing damage. A second bleed source when Horizon is already the core.",
    ),
  },
  {
    id: "heavenquaker-spear",
    name: "Heavenquaker Spear",
    kind: "Spear",
    path: "Bellstrike — Umbra",
    style: "Bellstrike",
    role: "Bleed payoff",
    blurb: "The spear that cashes in Umbra's bleed. Fewer hits to fill the martial buff if Wolfchaser is socketed.",
    signature: tome(
      "Wolfchaser's Art",
      "Core",
      "Lowers how many hits Heavenquaker needs to fill its martial buff, and a bleeding target can grant an extra combo point. This is the spear's reason to be in the pair.",
    ),
    second: tome(
      "Adaptive Steel",
      "Shred",
      "On spears, hits ignore a slice of physical defense. On Strategic Sword the same Inner Way is a chance to bleed after affinity damage instead.",
    ),
  },
  {
    id: "infernal-twinblades",
    name: "Infernal Twinblades",
    kind: "Twinblades",
    path: "Bamboocut — Wind",
    style: "Bamboocut",
    role: "Pressure",
    blurb: "Fast dual blades. The rage loop is the weapon. OnKamii's 1v1 board has the Wind pair at T0.",
    signature: tome(
      "Echoes of Oblivion",
      "Core",
      "The Inner Way that changes the twinblade pressure loop. Light attacks stack the path's ignore-defense damage. Upgrade this before the flex slots.",
    ),
    second: tome(
      "Vendetta",
      "Tokens",
      "The follow-up slot on Wind sheets when rope-dart tokens are part of the loop. Keep it if the dart is how you restart pressure.",
    ),
  },
  {
    id: "mortal-rope-dart",
    name: "Mortal Rope Dart",
    kind: "Rope Dart",
    path: "Bamboocut — Wind",
    style: "Bamboocut",
    role: "Chase",
    blurb: "The interrupt and chase tool beside Infernal Twinblades. High passive damage, and it hates getting parried in Rodent Rampage.",
    signature: tome(
      "Vendetta",
      "Core",
      "Wind's rope-dart slot. Sheets put it next to Echoes of Oblivion when the dart is feeding the twinblade loop.",
    ),
    second: tome(
      "Breaking Point",
      "Execute",
      "The fourth name on three Wind builds. Use it when the fight is about the execute.",
    ),
  },
  {
    id: "everspring-umbrella",
    name: "Everspring Umbrella",
    kind: "Umbrella",
    path: "Bamboocut — Dust",
    style: "Bamboocut",
    role: "Mobile area",
    blurb: "Dust's umbrella. Resonance is the loop. OnKamii lists the pair at T1 in high-rank 1v1.",
    signature: tome(
      "Phantom Rally",
      "Core",
      "The umbrella anchor. Take it when Resonance is the thing you are actually playing.",
    ),
    second: tome(
      "Song of Tang",
      "Sustain",
      "The sustained flex on Dust once the umbrella or the dart core is socketed.",
    ),
  },
  {
    id: "unfettered-rope-dart",
    name: "Unfettered Rope Dart",
    kind: "Rope Dart",
    path: "Bamboocut — Dust",
    style: "Bamboocut",
    role: "Sweep",
    blurb: "Dust's rope dart. Sweeps and multi-target control, not the Wind dart's chase loop.",
    signature: tome(
      "Towline Sweep",
      "Core",
      "The dart anchor. Take it when the sweep, not umbrella Resonance, is the reason you equipped Dust.",
    ),
    second: tome(
      "Light Anew",
      "Control",
      "Matters when you are controlling more than one target. A dead slot in a pure 1v1 that never sets up the control.",
    ),
  },
  {
    id: "heavenwill-gauntlets",
    name: "Heavenwill Gauntlets",
    kind: "Gauntlets",
    path: "Bamboocut — Kite",
    style: "Bamboocut",
    role: "Close burst",
    blurb: "Heaven's Will cash-out. OnKamii's strongest 1v1 mixes all start here. The designed dart pair is T0.5, not the top of the board.",
    signature: tome(
      "Soaring High",
      "Core",
      "The gauntlet anchor when Heaven's Will is the cash-out you built the loop around.",
    ),
    second: tome(
      "Celestial Vigor",
      "Support",
      "The comparison slot beside Soaring High on Kite primers. Keep it if the gauntlet, not the dart handoff, is starving.",
    ),
  },
  {
    id: "skygrasp-rope-dart",
    name: "Skygrasp Rope Dart",
    kind: "Rope Dart",
    path: "Bamboocut — Kite",
    style: "Bamboocut",
    role: "Setup",
    blurb: "Sets the Kite handoff into Falcon's Pursuit or Vile Condemned, then gets out.",
    signature: tome(
      "Sky Gripped",
      "Core",
      "The dart anchor. Socket it when the rope dart is the setup and the gauntlets are the payoff.",
    ),
    second: tome(
      "Empirical Edge",
      "Handoff",
      "The other Kite comparison piece. Use it when the dart-to-gauntlet handoff is the whole fight plan.",
    ),
  },
  {
    id: "skystrike-gauntlets",
    name: "Skystrike Gauntlets",
    kind: "Gauntlets",
    path: "Bamboocut — Draught",
    style: "Bamboocut",
    role: "Drunk burst",
    blurb: "Drunken Fist gauntlets. Damage lives in a short Deepdaze window. OnKamii calls the pair the most ping-dependent T0.",
    signature: tome(
      "Eonpour",
      "Core",
      "In the Inebriate state, path skills deal more base damage. At high tier it enables Drunkslay, which stores enhanced damage and detonates when the debuff ends.",
    ),
    second: tome(
      "Volutefit",
      "Guard",
      "Damage reduction during Winebound states. The survival piece for a burst that dies if you are interrupted.",
    ),
  },
  {
    id: "riven-twinblades",
    name: "Riven Twinblades",
    kind: "Twinblades",
    path: "Bamboocut — Draught",
    style: "Bamboocut",
    role: "Drunk burst",
    blurb: "The blade half of Draught. Skyspeak is what extends Deepdaze so the swap actually fits.",
    signature: tome(
      "Skyspeak",
      "Core",
      "Extends Deepdaze for Riven Twinblades. Without it the drunken window is too short for the swap the path is built on.",
    ),
    second: tome(
      "Mistwing",
      "Pen",
      "Penetration support for Draught. Bench it in 1v1 if you cannot finish the window.",
    ),
  },
  {
    id: "vernal-umbrella",
    name: "Vernal Umbrella",
    kind: "Umbrella",
    path: "Silkbind — Jade",
    style: "Silkbind",
    role: "Ranged control",
    blurb: "Projectiles, a ranged stun, and space. Jade is T0 in 1v1 and S on Game8's PvP list. Patience beats greed.",
    signature: tome(
      "Blossom Barrage",
      "Core",
      "The umbrella anchor on Jade primers. Socket it before the fan pieces.",
    ),
    second: tome(
      "Thunderous Bloom",
      "Move",
      "The movement-heavy attack option once Blossom Barrage is in. Prefer it over Flying Gourds unless you want the fan's charge tradeoff.",
    ),
  },
  {
    id: "inkwell-fan",
    name: "Inkwell Fan",
    kind: "Fan",
    path: "Silkbind — Jade",
    style: "Silkbind",
    role: "Ranged punish",
    blurb: "The fan teleports and sets the punish after the umbrella has already made them miss.",
    signature: tome(
      "Star Reacher",
      "Core",
      "The fan setup Inner Way. Pair it with Blossom Barrage, not instead of it, when both Jade weapons are out.",
    ),
    second: tome(
      "Flying Gourds",
      "Tradeoff",
      "Only when you accept the Inkwell Fan charge tradeoff. Otherwise Thunderous Bloom is the cleaner fourth.",
    ),
  },
  {
    id: "panacea-fan",
    name: "Panacea Fan",
    kind: "Fan",
    path: "Silkbind — Deluge",
    style: "Silkbind",
    role: "Healer",
    blurb: "The group healer. In 1v1 it is a kite-and-cleanse duelist, ranked T3 / B, not a damage path.",
    signature: tome(
      "Royal Remedy",
      "Core",
      "The Panacea healing loop. This is the tome you level before the umbrella pieces.",
    ),
    second: tome(
      "Restoring Blossom",
      "Crit heal",
      "Rewards critical healing. It wants the crit rate the attribute row is already chasing.",
    ),
  },
  {
    id: "soulshade-umbrella",
    name: "Soulshade Umbrella",
    kind: "Umbrella",
    path: "Silkbind — Deluge",
    style: "Silkbind",
    role: "Healer",
    blurb: "Resource recovery for the fan. Not a second damage umbrella.",
    signature: tome(
      "Mending Loom",
      "Core",
      "Umbrella resource recovery for Deluge. The slot that lets the fan keep casting.",
    ),
    second: tome(
      "Esoteric Revival",
      "Revive",
      "A revive tool, not a general slot. Socket it for group content where a pick-up wins the fight. Bench it in 1v1.",
    ),
  },
  {
    id: "thundercry-blade",
    name: "Thundercry Blade",
    kind: "Blade",
    path: "Stonesplit — Might",
    style: "Stonesplit",
    role: "Counter tank",
    blurb: "Parry into Avalanche. You stand in the hit so the spear's taunt and your shields can matter.",
    signature: tome(
      "Exquisite Scenery",
      "Core",
      "A successful parry skips a phase of Avalanche, on a cooldown. The blade's reason to parry instead of dodging out.",
    ),
    second: tome(
      "Art of Resistance",
      "Shield",
      "Increases shield HP and the effects tied to that shield for a few seconds. It wants a shield in the same build.",
    ),
  },
  {
    id: "stormbreaker-spear",
    name: "Stormbreaker Spear",
    kind: "Spear",
    path: "Stonesplit — Might",
    style: "Stonesplit",
    role: "Taunt tank",
    blurb: "Storm Roar is the taunt. Rock Solid adds damage reduction and, on the tome, cuts your own damage by 10%.",
    signature: tome(
      "Rock Solid",
      "Core",
      "Storm Roar grants extra damage reduction. The tome also reduces the damage you deal by 10%. You are buying the right to stand there.",
    ),
    second: tome(
      "Trapped Beast",
      "Emergency",
      "Below 30% HP, a shield for up to 30% of max HP. Long trigger gap. The once-a-fight save.",
    ),
  },
  {
    id: "snowparting-blade",
    name: "Snowparting Blade",
    kind: "Blade",
    path: "Stonesplit — Strength",
    style: "Stonesplit",
    role: "Duel burst",
    blurb: "The Heng-style blade. Quicker than the charged Phalanxbane plan, which is why PvP sheets prefer it. The pair is T0 / S.",
    signature: tome(
      "Frost-Clad Night",
      "Core",
      "A deflect, or a fully cast Grave Frost, unlocks Finding Spring: a fast follow-up that spends Blade Momentum and grants Tenacity. This is the PvP loop.",
    ),
    second: tome(
      "Invigorated Warrior",
      "Conditional",
      "Damage up while you are not being hit. Getting hit shuts it off and raises damage taken. Risky in 1v1, fine if you are the one deflecting.",
    ),
  },
  {
    id: "phalanxbane-blade",
    name: "Phalanxbane Blade",
    kind: "Blade",
    path: "Stonesplit — Strength",
    style: "Stonesplit",
    role: "Charged damage",
    blurb: "The charged Stonesplit blade. Excellent into bosses that stand still. In a duel, players will not let the stacks live.",
    signature: tome(
      "Throat-Piercing Art",
      "Core",
      "Combo hits stack Throat-Pierced. Stacks ignore some physical resistance and add critical damage. Game8 tells you to take it off in PvP, because a player will not let you hold the stacks.",
    ),
    second: tome(
      "Steadfast Devotion",
      "Crit",
      "At tier 3, the Phalanxbane sheets use it so a high crit rate becomes a reliable crit. Keep it on the charged boss plan. It is not the 1v1 flex.",
    ),
  },
  {
    id: "museflow-drum",
    name: "Museflow Waist Drum",
    kind: "Drum",
    path: "Silkbind — Wings",
    style: "Silkbind",
    role: "Melody",
    blurb: "The drum half of Wings, new in Version 2.3. Rippling Dew spends 100 Noble Will on one melody: damage, a shield, or a knockdown.",
    signature: tome(
      "Harmony Song",
      "Core",
      "While Rustling is up, Rippling Dew grants Radiant Drum: 6% to every attack type and 10% movement for you and nearby allies, plus Tenacity on you. At tier 4 it can reset Rippling Dew and refill Noble Will once every 60 seconds. This is the tome Game8 tells you to raise first.",
    ),
    second: tome(
      "Ink and Strings",
      "Buff",
      "While an attack buff is on you, damage and healing rise at high HP, and you drain HP at low HP. Tier 6 adds penetration on the drumbeat skills. It does nothing if Rustling and Radiant Drum are down.",
    ),
  },
  {
    id: "willowbend-fan",
    name: "Willowbend Fan",
    kind: "Fan",
    path: "Silkbind — Wings",
    style: "Silkbind",
    role: "Buff setup",
    blurb: "The fan half of Wings. It opens the spacing, puts Rustling on the team, and feeds Noble Will back to the drum.",
    signature: tome(
      "Zephyr Whispers",
      "Core",
      "Unlocks End of Gale after Verdant Gust or Boundless Bloom. Tier 3 restores 30 Noble Will per target, up to twice every 15 seconds. Tier 6 raises the attack buffs. Without this, the fan cannot refill the drum.",
    ),
    second: tome(
      "Blade's Will",
      "Crowd",
      "Hits on several bodies apply Blade of Grass. At tier 6, five stacks root for 4 seconds. Game8 swaps this in for guild fights. It is a weak 1v1 slot, because one opponent does not stack it.",
    ),
  },
];

const byId = new Map(ARTS.map((art) => [art.id, art]));

function art(id: string): Art {
  const found = byId.get(id);
  if (!found) throw new Error(`Unknown martial art: ${id}`);
  return found;
}

export const suggest: Record<string, Suggestion[]> = {
  "nameless-sword": [
    { id: "infernal-twinblades", label: "Ranked mix", rank: "T0", board: "Mix", why: "OnKamii's fifth-strongest 1v1 pair. Sword Morph only fires on the sword. Echoes of Oblivion only fires on the blades." },
    { id: "nameless-spear", label: "Path pair", rank: "T1", board: "S", why: "Designed Splendor pair. Game8's 1v1 bar is Sword Morph, Morale Chant, Fury Harvest, Evasive Charge." },
    { id: "strategic-sword", label: "Ranked mix", rank: "T2", board: "A", why: "OnKamii T2, Game8 A. Same Bellstrike arsenal. Weaker than the twinblade mix." },
  ],
  "nameless-spear": [
    { id: "heavenwill-gauntlets", label: "Ranked mix", rank: "T0", board: "Mix", why: "OnKamii's number-one pair this patch. Spear answers Tenacity. Gauntlets cash Heaven's Will." },
    { id: "strategic-sword", label: "Ranked mix", rank: "T0.5", board: "A", why: "Averse's rank-1 weapons. Inner ways he queued: Sword Horizon, Morale Chant, Fury Harvest, Evasive Charge." },
    { id: "nameless-sword", label: "Path pair", rank: "T1", board: "S", why: "Designed Splendor pair. OnKamii T1, up from T2. Game8 S." },
  ],
  "strategic-sword": [
    { id: "nameless-spear", label: "Ranked mix", rank: "T0.5", board: "A", why: "The loadout a rank-1 player actually queued. Sword Horizon is the tome that only works on this sword." },
    { id: "heavenquaker-spear", label: "Path pair", rank: "T1", board: "A", why: "Designed Umbra pair. OnKamii T1: huge damage, burns stamina, and they can run if you have no catch. Game8 A." },
  ],
  "heavenquaker-spear": [
    { id: "strategic-sword", label: "Path pair", rank: "T1", board: "A", why: "Designed Umbra pair. Wolfchaser only shortens the spear buff on a bleeding target." },
    { id: "nameless-sword", label: "Ranked mix", rank: "T2", board: "A", why: "Nameless Sword with an Umbra weapon sits at T2 / A." },
  ],
  "infernal-twinblades": [
    { id: "heavenwill-gauntlets", label: "Ranked mix", rank: "T0", board: "Mix", why: "OnKamii: Heavenwill with Infernal may be the first or second pair, depending on the player." },
    { id: "mortal-rope-dart", label: "Path pair", rank: "T0", board: "A", why: "Designed Wind pair. OnKamii's second-best pair. Version 2.0 cut the Qi damage you take when Rodent Rampage is deflected." },
    { id: "nameless-sword", label: "Ranked mix", rank: "T0", board: "Mix", why: "Fifth on that same board. Different styles, so the arsenal is General." },
  ],
  "mortal-rope-dart": [
    { id: "heavenwill-gauntlets", label: "Ranked mix", rank: "T0", board: "Mix", why: "OnKamii lists Heavenwill with Mortal Rope Dart in T0. Dart pressure, gauntlet cash-out." },
    { id: "infernal-twinblades", label: "Path pair", rank: "T0", board: "A", why: "Designed Wind pair. Second-best on his 1v1 board. Game8 PvP is A." },
  ],
  "everspring-umbrella": [
    { id: "unfettered-rope-dart", label: "Path pair", rank: "T1", board: "A", why: "Designed Dust pair. T1 in 1v1, A on Game8. The throw now shows a warning flash." },
  ],
  "unfettered-rope-dart": [
    { id: "everspring-umbrella", label: "Path pair", rank: "T1", board: "A", why: "Designed Dust pair." },
  ],
  "heavenwill-gauntlets": [
    { id: "nameless-spear", label: "Ranked mix", rank: "T0", board: "Mix", why: "The pair OnKamii called the strongest in the game. Only the gauntlet charge gets through a held block." },
    { id: "infernal-twinblades", label: "Ranked mix", rank: "T0", board: "Mix", why: "He says this may be first or second, depending on who is playing it." },
    { id: "mortal-rope-dart", label: "Ranked mix", rank: "T0", board: "Mix", why: "The other T0 gauntlet mix. Dart pressure, gauntlet cash-out." },
    { id: "skygrasp-rope-dart", label: "Path pair", rank: "T0.5", board: "S", why: "Designed Kite pair. OnKamii T0.5, Game8 PvP S. It lacks the spear's answer to Tenacity." },
  ],
  "skygrasp-rope-dart": [
    { id: "heavenwill-gauntlets", label: "Path pair", rank: "T0.5", board: "S", why: "Designed Kite pair. T0.5 in high-rank 1v1, S on Game8's PvP list." },
  ],
  "skystrike-gauntlets": [
    { id: "riven-twinblades", label: "Path pair", rank: "T0", board: "A", why: "Designed Draught pair. T0, and the most ping-dependent duo on that board." },
  ],
  "riven-twinblades": [
    { id: "skystrike-gauntlets", label: "Path pair", rank: "T0", board: "A", why: "Designed Draught pair." },
  ],
  "vernal-umbrella": [
    { id: "inkwell-fan", label: "Path pair", rank: "T0", board: "S", why: "Designed Jade pair. Fourth-strongest on OnKamii's 1v1 board, S on Game8. Never nerfed. Struggles into Heavenwill." },
  ],
  "inkwell-fan": [
    { id: "vernal-umbrella", label: "Path pair", rank: "T0", board: "S", why: "Designed Jade pair." },
  ],
  "panacea-fan": [
    { id: "soulshade-umbrella", label: "Path pair", rank: "T3", board: "B", why: "Designed Deluge pair. A healer in a duel is a kite plan, not a damage plan." },
  ],
  "soulshade-umbrella": [
    { id: "panacea-fan", label: "Path pair", rank: "T3", board: "B", why: "Designed Deluge pair. OnKamii moved it up after a Soulshade buff that lets healers swap into combos." },
  ],
  "thundercry-blade": [
    { id: "snowparting-blade", label: "Ranked mix", rank: "T0.5", board: "Mix", why: "OnKamii's easy pair that wins a lot. T0.5. Both Stonesplit." },
    { id: "stormbreaker-spear", label: "Path pair", rank: "T1", board: "B", why: "Designed Might pair. Hard to break, and people run away and chip it." },
  ],
  "stormbreaker-spear": [
    { id: "thundercry-blade", label: "Path pair", rank: "T1", board: "B", why: "Designed Might pair. Game8's PvP row wants Serene Breeze, and Vital Leech when you execute." },
    { id: "snowparting-blade", label: "Ranked mix", rank: "T1", board: "Mix", why: "OnKamii also rates Snowparting with Stormbreaker at T1." },
  ],
  "snowparting-blade": [
    { id: "phalanxbane-blade", label: "Path pair", rank: "T0", board: "S", why: "One of OnKamii's top three, S on Game8. Duel on Frost-Clad Night. Throat-Piercing comes off in PvP." },
    { id: "thundercry-blade", label: "Ranked mix", rank: "T0.5", board: "Mix", why: "The easier T0.5 he recommends when you want wins more than the Strength ceiling." },
    { id: "nameless-spear", label: "Ranked mix", rank: "T1", board: "Mix", why: "OnKamii T1. Spear catch into the blade. Different styles." },
  ],
  "phalanxbane-blade": [
    { id: "snowparting-blade", label: "Path pair", rank: "T0", board: "S", why: "Designed Strength pair. If the duel is the goal, Snowparting is the weapon you actually play." },
  ],
  "museflow-drum": [
    { id: "willowbend-fan", label: "Path pair", rank: "S group", board: "New", why: "Designed Wings pair, added October 15, 2026. The Oct 16 guide rates it S in guild battles and much weaker in 1v1. It was not on the Sept 19 board." },
  ],
  "willowbend-fan": [
    { id: "museflow-drum", label: "Path pair", rank: "S group", board: "New", why: "Designed Wings pair. The fan applies Rustling. The drum spends Noble Will." },
  ],
};

const hawkwing: SetBonus = {
  name: "Hawkwing",
  where: "Weapons, pendant, disc",
  bonus: "2 pieces: Affinity Rate. 4 pieces: when damage triggers Affinity, gain a stack of physical attack.",
};
const swallow: SetBonus = {
  name: "Swallowcall",
  where: "Weapons, pendant, disc",
  bonus: "2 pieces: minimum physical attack. The PvP weapon set for light-attack strings.",
};
const calmwaters: SetBonus = {
  name: "Calmwaters",
  where: "Armor",
  bonus: "Perfect Dodge can restore HP and endurance. Game8's 1v1 armor for Splendor.",
};
const rainwhisper: SetBonus = {
  name: "Rainwhisper",
  where: "Armor",
  bonus: "The healer armor on the Deluge sheet.",
};
const ivory: SetBonus = {
  name: "Ivorybloom",
  where: "Weapons, pendant, disc",
  bonus: "The crit-heal weapon set on the Deluge sheet.",
};
const agile: SetBonus = {
  name: "Agile Steps",
  where: "Armor",
  bonus: "The PvP armor named for a deflect-and-leave plan.",
};
const shattered: SetBonus = {
  name: "Shattered Ridge",
  where: "Weapons, pendant, disc",
  bonus: "The weapon set named on the Strength sheet.",
};
const cloudshear: SetBonus = {
  name: "Cloudshear",
  where: "Weapons, pendant, disc",
  bonus: "2 pieces: minimum physical attack. 4 pieces: an attack buff on you or an ally also grants Cloudshear, 2% damage and healing for 15 seconds. On yourself that becomes Cloudshear: Wings, 6%.",
};
const reinchime: SetBonus = {
  name: "Reinchime",
  where: "Armor",
  bonus: "2 pieces: physical defense. 4 pieces: an attack buff grants 2% damage reduction for 5 seconds, or 6% as Reinchime: Wings on yourself.",
};

const serene = tome("Serene Breeze", "Break", "The combo break. Averse calls it mandatory, and Game8 puts it first on 1v1 rows.");
const cloudSteps = tome("Cloud Steps", "Gap", "The gap close when neither weapon immobilizes.");
const dragonsBreath = tome("Dragon's Breath", "Burst", "Fortitude burst after something has already stopped them. Do not open with it.");
const talon = tome("Talon Strike", "Block", "Breaks a held block, with Tenacity. The answer when they hold block against a gauntlet charge.");
const ghostly = tome("Ghostly Steps", "Leave", "Wind's disengage. Rodent Rampage dies when it is parried.");
const toad = tome("Leaping Toad", "Move", "Arena-tagged movement on filmed loadouts.");
const freeMorph = tome("Free Morph", "Leave", "Deluge's published way out.");
const golden = tome("Golden Body", "Shield", "Shield, Tenacity, and damage reduction. Tenacity lasts less time in Arena.");
const soaring = tome("Soaring Spin", "Cut", "A thrust, then a spiral. Cuts healing received by 60% for 5 seconds. Use it while Rippling Dew is down.");
const flute = tome("Flute of the Tides", "Opener", "Starfall notes, then short follow-ups. Cancel after the first hit so the fan setup is not late.");
const USAGE: Record<string, number> = {
  "heavenwill-gauntlets|nameless-spear": 12,
  "heavenwill-gauntlets|infernal-twinblades": 9,
  "infernal-twinblades|mortal-rope-dart": 8,
  "phalanxbane-blade|snowparting-blade": 10,
  "snowparting-blade|thundercry-blade": 9,
  "inkwell-fan|vernal-umbrella": 8,
  "nameless-spear|strategic-sword": 7,
  "infernal-twinblades|nameless-sword": 6,
  "heavenwill-gauntlets|mortal-rope-dart": 5,
  "heavenwill-gauntlets|skygrasp-rope-dart": 5,
  "riven-twinblades|skystrike-gauntlets": 4,
  "nameless-spear|nameless-sword": 4,
  "heavenquaker-spear|strategic-sword": 3,
  "everspring-umbrella|unfettered-rope-dart": 2,
  "stormbreaker-spear|thundercry-blade": 2,
  "snowparting-blade|stormbreaker-spear": 2,
  "nameless-spear|snowparting-blade": 1,
  "nameless-sword|strategic-sword": 1,
  "heavenquaker-spear|nameless-sword": 1,
  "panacea-fan|soulshade-umbrella": 1,
};

export function playerShare(a: string, b: string): string {
  const key = [a, b].sort().join("|");
  const share = USAGE[key];
  return share == null ? "Under 1%" : `${share}%`;
}

const DUOS: Duo[] = [
  {
    ids: ["nameless-sword", "nameless-spear"],
    arenaRank: "T1",
    board: "S",
    mix: false,
    headline: "Hold mid-range, then a short punish",
    read: "Splendor is OnKamii T1, up from T2, and Game8 S. The chestpiece now cuts damage while a player is controlled, so the immobilize into Soaring Spin hits less hard. Heavenwill and twinblades are the hard matchups. Stay close and deflect.",
    arsenal: "Bellstrike",
    arsenalWhy: "Both weapons are Bellstrike.",
    source: "Game8 Nameless Spear and Nameless Sword build, checked against the Oct 11 2026 Splendor PvP page. OnKamii, Sept 19 2026: T1.",
    arena: {
      inner: [art("nameless-sword").signature, chant, fury, evasive],
      mystic: [
        tome("Serene Breeze", "Break", "Game8's first 1v1 mystic. Break the combo, then reset to mid-range. Do not hit their Super Armor after it."),
        tome("Talon Strike", "Punish", "Breaks a guard that is holding block, with Tenacity."),
        tome("Cloud Steps", "Gap", "A situational opener. Do not use the same approach every time."),
        tome("Dragon's Breath", "Burst", "The short punish after Qiankun's Lock. Save it. Do not open with it."),
      ],
      offense: hawkwing,
      defense: calmwaters,
      gearNote: "Calmwaters on armor, because a Perfect Dodge can restore HP and endurance. Hawkwing on weapons. Damage Boost against Players on greaves and bracer.",
      stats: [
        { name: "Precision Rate", target: "So the lock lands", detail: "Qiankun's Lock is the punish window. A miss is not a combo." },
        { name: "Max Bellstrike Attack", target: "Arsenal", detail: "Both weapons are Bellstrike." },
        { name: "Affinity Rate", target: "Only if Hawkwing is proccing", detail: "Do not chase an affinity cap if Vagrant Sword keeps getting deflected." },
        { name: "Endurance", target: "Leave some", detail: "An empty bar cannot Perfect Dodge, and that is the easy punish." },
      ],
      loop: "Let them overcommit. Qiankun's Lock when they commit, or one Daunting Strike from mid-range and Shadow Step if it whiffs. Follow the lock with Dragon's Breath or a short spear string. Do not fire Vagrant Sword from a distance they expect. When they Serene Breeze, stop.",
    },
  },
  {
    ids: ["strategic-sword", "heavenquaker-spear"],
    arenaRank: "T1",
    board: "A",
    mix: false,
    headline: "Bleed, then make the spear shorter",
    read: "OnKamii puts the designed Umbra pair at T1. The damage is huge, it burns stamina, and without a catch they run. Game8's letter is A. The higher 1v1 citation is Strategic Sword with Nameless Spear.",
    arsenal: "Bellstrike",
    arsenalWhy: "Both weapons are Bellstrike.",
    source: "Game8 Umbra comparisons. OnKamii, Sept 19 2026: T1.",
    arena: {
      inner: [art("strategic-sword").signature, art("heavenquaker-spear").signature, chant, tome("Insightful Strike", "Focus", "Game8 keeps it as a fourth when you live on affinity. Breaking Point is the other fourth if the execute is the plan.")],
      mystic: [
        tome("Serene Breeze", "Break", "Game8's PvP mystic row for this path."),
        tome("Cloud Steps", "Gap", "Bleed does not help you if they leave."),
        tome("Meridian Touch", "Lock", "A ranged hold so the bleed ticks on a target that would kite the spear."),
        tome("Leaping Toad", "Arena", "The fourth name on that PvP row."),
      ],
      offense: hawkwing,
      defense: calmwaters,
      gearNote: "Hawkwing is the weapon set on the Umbra comparisons. Calmwaters is the Bellstrike 1v1 armor from the sister path, not an Umbra-specific citation.",
      stats: [
        { name: "Precision Rate", target: "High", detail: "Bleed and the spear buff both need the hit to land." },
        { name: "Affinity Rate", target: "Feed Hawkwing", detail: "Sword Horizon cares about the hit that applies bleed. Do not copy a Splendor affinity cap." },
        { name: "Min Physical Attack", target: "With the max", detail: "Bleed ticks like the floor of your attack." },
        { name: "Max Bellstrike Attack", target: "Arsenal", detail: "Only while the arsenal stays Bellstrike." },
      ],
      loop: "Strategic martial, charged, or special into the Horizon follow-up so the target is bleeding. Heavenquaker spends that bleed. Do not open with the spear into a target that is not bleeding yet.",
    },
  },
  {
    ids: ["infernal-twinblades", "mortal-rope-dart"],
    arenaRank: "T0",
    board: "A",
    mix: false,
    headline: "Do not get parried, do not drop rage",
    read: "OnKamii's second-best 1v1 pair. Version 2.0 cut the Qi damage you take when Rodent Rampage is deflected. Game8's PvP letter is A. The gap is execution.",
    arsenal: "Bamboocut",
    arsenalWhy: "Both weapons are Bamboocut.",
    source: "OnKamii, Sept 19 2026. Wind inner ways from the compared sheets. Game8 PvP: A.",
    arena: {
      inner: [art("infernal-twinblades").signature, art("infernal-twinblades").second, chant, art("mortal-rope-dart").second],
      mystic: [
        tome("Serene Breeze", "Break", "On the Wind PvP mystic list."),
        tome("Talon Strike", "Punish", "On the same list."),
        tome("Guardian Palm", "Answer", "Named beside the break tools for Wind in PvP."),
        tome("Ghostly Steps", "Leave", "The disengage. Wind dies when Rodent Rampage is parried and you have no way out."),
      ],
      offense: swallow,
      defense: calmwaters,
      gearNote: "Swallowcall is the PvP weapon set. Hawkwing is the PvE pairing. If you stay on Hawkwing, raise affinity. Swallowcall wants affinity kept low.",
      stats: [
        { name: "Precision Rate", target: "About 100%", detail: "Wind's damage is a lot of small hits. Misses fall off a cliff." },
        { name: "Critical Rate", target: "70–73% on Swallowcall", detail: "Game8's Swallowcall band. Do not mix it with a Hawkwing crit band." },
        { name: "Affinity Rate", target: "Low on Swallowcall", detail: "Match the set you actually wear." },
        { name: "Bamboocut Attack", target: "Arsenal", detail: "After the rates." },
      ],
      loop: "Build the twinblade resource, tag with the dart, and keep rage from falling off. If they start parrying Rodent Rampage, stop mashing it. Ghostly Steps is the leave button.",
    },
  },
  {
    ids: ["everspring-umbrella", "unfettered-rope-dart"],
    arenaRank: "T1",
    board: "A",
    mix: false,
    headline: "Resonance or the sweep, not both at once",
    read: "Dust is T1 / A. OnKamii calls it annoying because of umbrella-throw mix-ups, and a little weaker since Version 2.0: the charge's Tenacity starts after 0.5 seconds, and the unblockable throw shows a warning flash.",
    arsenal: "Bamboocut",
    arsenalWhy: "Both weapons are Bamboocut.",
    source: "OnKamii, Sept 19 2026. Inner ways are the tomes that turn each Dust weapon on. No Dust-specific mystic card was in the sources.",
    arena: {
      inner: [art("everspring-umbrella").signature, art("unfettered-rope-dart").signature, art("everspring-umbrella").second, chant],
      mystic: [cloudSteps, serene, tome("Meridian Touch", "Hold", "A hold, so the sweep has a body to land on. Not printed on a Dust sheet."), toad],
      offense: hawkwing,
      defense: calmwaters,
      gearNote: "No Dust-specific set was pinned. Hawkwing fits a path that hits often enough to stack affinity. Treat it as a fit, not a filmed card.",
      stats: [
        { name: "Precision Rate", target: "High", detail: "Area hits still miss." },
        { name: "Min Physical Attack", target: "With the max", detail: "Sweeps care about the floor." },
        { name: "Bamboocut Attack", target: "Arsenal", detail: "Matching arsenal." },
        { name: "Critical Rate", target: "After precision", detail: "Do not buy crit by dumping precision." },
      ],
      loop: "If Phantom Rally is socketed, play umbrella Resonance and use the dart to reposition. If Towline Sweep is the tome you trusted, the dart is the attack. Light Anew only earns a slot when more than one enemy is controlled.",
      note: "Mystic row is the arena toolkit. Inner ways are the path tomes.",
    },
    group: {
      inner: [art("everspring-umbrella").signature, art("unfettered-rope-dart").signature, art("unfettered-rope-dart").second, chant],
      note: "In a pile, Light Anew replaces Song of Tang. The control tome wants more than one body.",
    },
  },
  {
    ids: ["heavenwill-gauntlets", "skygrasp-rope-dart"],
    arenaRank: "T0.5",
    board: "S",
    mix: false,
    headline: "Charge through the block, or don't",
    read: "Kite is OnKamii T0.5 and Game8 PvP S. He says the damage is high and the pair still lacks the Nameless Spear's answer to Tenacity. Against it, hold block: only the gauntlet charge gets through.",
    arsenal: "Bamboocut",
    arsenalWhy: "Both weapons are Bamboocut. Heavenwill's talent also scales off Bamboocut attack.",
    source: "OnKamii, Sept 19 2026, with the block note from the tier video. Game8 PvP: S. No Kite 1v1 socket card was published.",
    arena: {
      inner: [art("heavenwill-gauntlets").signature, art("skygrasp-rope-dart").signature, chant, evasive],
      mystic: [serene, talon, cloudSteps, toad],
      offense: swallow,
      defense: calmwaters,
      gearNote: "Swallowcall fits the light attacks. No Kite set card was published.",
      stats: [
        { name: "Precision Rate", target: "The charge has to hit", detail: "A blocked string does nothing. The charge is the hit that gets through." },
        { name: "Bamboocut Attack", target: "Arsenal", detail: "Feeds the gauntlet talent." },
        { name: "Critical Rate", target: "On the cash-out", detail: "After precision." },
        { name: "Max HP", target: "Enough to step in", detail: "You are walking into melee on purpose." },
      ],
      loop: "Dart sets the handoff. Gauntlets spend Heaven's Will. If they hold block, the charge is the button. If they have Tenacity up, this pair does not have the spear's answer. Leave.",
    },
  },
  {
    ids: ["skystrike-gauntlets", "riven-twinblades"],
    arenaRank: "T0",
    board: "A",
    mix: false,
    headline: "A short drunk window, or nothing",
    read: "OnKamii puts Draught in T0 and calls it the most ping-dependent pair in the game. The damage lives inside Inebriate. Skyspeak only makes that window long enough to swap.",
    arsenal: "Bamboocut",
    arsenalWhy: "Both weapons are Bamboocut.",
    source: "OnKamii, Sept 19 2026. Inner ways are Eonpour and Skyspeak, the tomes the window is built on, plus Volutefit so an interrupt does not delete you.",
    arena: {
      inner: [art("skystrike-gauntlets").signature, art("riven-twinblades").signature, art("skystrike-gauntlets").second, chant],
      mystic: [serene, cloudSteps, talon, golden],
      offense: swallow,
      defense: calmwaters,
      gearNote: "Swallowcall for the light attacks inside the window. No separate Draught set card was used.",
      stats: [
        { name: "Precision Rate", target: "The window has to land", detail: "A missed string inside Deepdaze is a wasted Drunkslay." },
        { name: "Bamboocut Attack", target: "Arsenal", detail: "Shared style." },
        { name: "Critical Rate", target: "Inside the window", detail: "After the hits are reliable." },
        { name: "Max HP", target: "Survive the interrupt", detail: "Volutefit is the reduction. It is not a second health bar." },
      ],
      loop: "Enter Inebriate on the gauntlets. Swap to the twinblades while Skyspeak is extending Deepdaze. Detonate as the debuff ends. If your ping cannot finish it, this T0 is not your T0.",
    },
  },
  {
    ids: ["vernal-umbrella", "inkwell-fan"],
    arenaRank: "T0",
    board: "S",
    mix: false,
    headline: "Make them miss, then Spring Away",
    read: "OnKamii's fourth-strongest pair. He says Jade has never been nerfed and only struggles against Heavenwill. The umbrella makes them miss. The fan is the punish, including a guard break.",
    arsenal: "Silkbind",
    arsenalWhy: "Both weapons are Silkbind.",
    source: "OnKamii, Sept 19 2026: T0. Game8 PvP: S. Inner ways are the umbrella and fan anchors from the Jade primers.",
    arena: {
      inner: [art("vernal-umbrella").signature, art("inkwell-fan").signature, art("vernal-umbrella").second, chant],
      mystic: [cloudSteps, serene, tome("Wolflike Frenzy", "Punish", "The step-in after they miss. Not the opener."), tome("Meridian Touch", "Hold", "A hold when the ranged stun is down.")],
      offense: hawkwing,
      defense: calmwaters,
      gearNote: "No Jade-specific 1v1 set card was pinned here. Hawkwing if the projectiles proc affinity. Do not craft for a melee string you are not playing.",
      stats: [
        { name: "Silkbind Attack", target: "Arsenal", detail: "Both weapons are Silkbind." },
        { name: "Precision Rate", target: "The projectile has to hit", detail: "A missed stun is a fan with nothing to punish." },
        { name: "Max HP", target: "Enough to be wrong once", detail: "Jade dies when it gets greedy and steps in early." },
        { name: "Critical Rate", target: "After the stun lands", detail: "The punish is the crit. The opener is the accuracy." },
      ],
      loop: "Stay at range. Stun or make them whiff. Fan teleport is the punish, not the approach. Against Heavenwill, do not stand in the charge.",
    },
  },
  {
    ids: ["panacea-fan", "soulshade-umbrella"],
    arenaRank: "T3",
    board: "B",
    mix: false,
    headline: "You are the healer who refuses the duel",
    read: "OnKamii moved Deluge up to T3 after a Soulshade buff that lets healers weapon-swap into combos. Game8 is B. In 1v1, if nobody dies, damage dealt decides it. This pair stalls. It does not burst.",
    arsenal: "Silkbind",
    arsenalWhy: "Both weapons are Silkbind.",
    source: "OnKamii, Sept 19 2026: T3. Game8 PvP: B. Esoteric Revival is benched in the duel because it is a pickup, not a damage tome.",
    arena: {
      inner: [art("panacea-fan").signature, art("soulshade-umbrella").signature, art("panacea-fan").second, chant],
      mystic: [serene, tome("Wolflike Frenzy", "Trade", "The offensive option the path was given. It does not make you a damage build."), freeMorph, toad],
      offense: ivory,
      defense: rainwhisper,
      gearNote: "Ivorybloom for critical healing. Rainwhisper on the armor. Do not put a damage 4-piece on the fan and call it a kill path.",
      stats: [
        { name: "Critical Rate", target: "For the heal", detail: "Restoring Blossom pays critical healing." },
        { name: "Max HP", target: "So the kite lasts", detail: "You win by still being alive when their endurance is gone." },
        { name: "Silkbind Attack", target: "Arsenal", detail: "Shared style. It will not out-damage a T0." },
        { name: "Precision Rate", target: "Enough to land the cleanse", detail: "A missed heal in a duel is a dead healer." },
      ],
      loop: "Heal, swap if the Soulshade combo is actually there, leave with Free Morph. Do not stand in a gauntlet charge to prove a point.",
    },
    group: {
      inner: [art("panacea-fan").signature, art("soulshade-umbrella").signature, art("soulshade-umbrella").second, chant],
      mystic: [golden, tome("Meridian Touch", "Hold", "Group hold."), tome("Flute of the Tides", "Buff", "Cast before the group's burst, the way Strength sheets use it."), cloudSteps],
      note: "Esoteric Revival comes back in a group, where a pickup wins the fight. It stays benched in 1v1.",
    },
  },
  {
    ids: ["thundercry-blade", "stormbreaker-spear"],
    arenaRank: "T1",
    board: "B",
    mix: false,
    headline: "Stand there on purpose",
    read: "Might is OnKamii T1 and Game8 B. Tenacity and Super Armor are hard to break. People run away and chip it. You are there to live and to parry, not to chase.",
    arsenal: "Stonesplit",
    arsenalWhy: "Both weapons are Stonesplit.",
    source: "Game8 Might page: Serene Breeze is mandatory in PvP, and Vital Leech replaces the PvE flex when you execute. OnKamii, Sept 19 2026: T1.",
    arena: {
      inner: [art("thundercry-blade").signature, art("stormbreaker-spear").signature, art("thundercry-blade").second, leech],
      mystic: [serene, golden, cloudSteps, toad],
      offense: shattered,
      defense: agile,
      gearNote: "Golden Body is the mystic shield. Agile Steps if you are deflecting. Do not play this like Strength.",
      stats: [
        { name: "Max HP", target: "The plan", detail: "Rock Solid and a parry both assume you are alive when the reduction ends." },
        { name: "Precision Rate", target: "The parry follow-up", detail: "A skipped Avalanche phase that misses is just a cooldown." },
        { name: "Stonesplit Attack", target: "Arsenal", detail: "You also deal 10% less because of Rock Solid. Do not expect Strength numbers." },
        { name: "Critical Rate", target: "After you can live", detail: "Survival first." },
      ],
      loop: "Storm Roar, take the Rock Solid reduction, parry into Avalanche with Exquisite Scenery. Vital Leech pays when you execute. Do not chase a player who has already left.",
    },
    group: {
      inner: [art("thundercry-blade").signature, art("stormbreaker-spear").signature, art("thundercry-blade").second, art("stormbreaker-spear").second],
      note: "In a pile, Trapped Beast replaces Vital Leech. Executions are less reliable when six people are hitting the same body.",
    },
  },
  {
    ids: ["snowparting-blade", "phalanxbane-blade"],
    arenaRank: "T0",
    board: "S",
    mix: false,
    headline: "Deflect, follow up, leave the long charge",
    read: "Strength is the consensus duel path. T0 and S. Play Snowparting. Phalanxbane's charged plan is the boss version, and Game8 takes Throat-Piercing off for PvP.",
    arsenal: "Stonesplit",
    arsenalWhy: "Both weapons are Stonesplit.",
    source: "Stonesplit Strength build page, version 2.2, last checked Oct 7 2026. Inner ways compared across g drag, hkurosagi, and Game8.",
    arena: {
      inner: [art("snowparting-blade").signature, chant, fury, evasive],
      mystic: [
        tome("Serene Breeze", "Break", "Game8's PvP mystic row for Strength."),
        tome("Talon Strike", "Punish", "On that same row."),
        tome("Leaping Toad", "Arena", "The in-game tag on g drag's loadout calls Toad recommended for Arena."),
        tome("Dragon Head", "Fill", "The other PvP name on the Game8 row. A filler when endurance is gone, not the opener."),
      ],
      offense: shattered,
      defense: agile,
      gearNote: "PvP armor they name is Agile Steps. Shattered Ridge is the weapon set. The chest roll for a duel is Snowparting combo damage, not a Phalanxbane charged-skill boost.",
      stats: [
        { name: "Precision Rate", target: "95–100%", detail: "Game8 for both modes. hkurosagi sits at 100%." },
        { name: "Critical Rate", target: "75–80%", detail: "Game8's PvP band for Snowparting. The Phalanxbane boss plan is not this row." },
        { name: "Max Physical Attack", target: "Then minimum", detail: "Game8 puts both attack stats after the rates." },
        { name: "Stonesplit Attack", target: "Arsenal", detail: "After the rates." },
      ],
      loop: "Deflect into Finding Spring. Spend one bar of Blade Momentum. Leave. Do not hold Throat-Piercing stacks against a person.",
    },
    group: {
      inner: [art("snowparting-blade").signature, art("phalanxbane-blade").signature, art("phalanxbane-blade").second, chant],
      note: "Throat-Piercing comes back when the fight is long enough that stacks survive. If you are the focus, stay on the arena row.",
    },
  },
  {
    ids: ["strategic-sword", "nameless-spear"],
    arenaRank: "T0.5",
    board: "A",
    mix: true,
    headline: "The rank-1 sword and spear",
    read: "Averse queued Strategic Sword with Nameless Spear at rank 1. OnKamii ranks the pair T0.5. Game8's letter is A. Both weapons are still Bellstrike. Sword Horizon does not function on the spear.",
    arsenal: "Bellstrike",
    arsenalWhy: "Same style. Do not switch the arsenal to General.",
    source: "Averse, rank 1 global 1v1: Morale Chant, Sword Horizon, Fury Harvest, Evasive Charge. Mystics from his combo notes: Serene Breeze, Dragon's Breath, Drunken Poet, Leaping Toad. OnKamii, Sept 19 2026: T0.5.",
    arena: {
      inner: [art("strategic-sword").signature, chant, fury, evasive],
      mystic: [
        tome("Serene Breeze", "Break", "Averse calls it the get-out-of-jail card. The fight is played around its cooldown."),
        tome("Dragon's Breath", "Burst", "He will not queue without it. Spear martial skill into Breath, then a parry cancel."),
        tome("Drunken Poet", "Buff", "The intoxicated buff is the condition on that spear-into-Breath combo. It also grants Tenacity."),
        tome("Leaping Toad", "Combo", "His extender: Strategic martial skill, the first hit of the special, then Toad."),
      ],
      offense: hawkwing,
      defense: calmwaters,
      gearNote: "Hawkwing is the Umbra weapon set. Calmwaters is Game8's 1v1 armor for the spear's dodge game. Averse did not publish a set card.",
      stats: [
        { name: "Precision Rate", target: "So the spear skill lands", detail: "The combo starts on Nameless Spear's martial skill." },
        { name: "Affinity Rate", target: "Feed the bleed", detail: "Not a Splendor affinity-cap build." },
        { name: "Min Physical Attack", target: "With the max", detail: "Bleed ticks and spear chips." },
        { name: "Max Bellstrike Attack", target: "Arsenal", detail: "Both weapons are Bellstrike." },
      ],
      loop: "Drunken Poet, then Nameless Spear martial skill into Dragon's Breath and a parry cancel, then Strategic Sword. Serene Breeze is for leaving, not for opening.",
      note: "This is a filmed rank-1 loadout for this exact pair.",
    },
  },
  {
    ids: ["nameless-sword", "infernal-twinblades"],
    arenaRank: "T0",
    board: "Mix",
    mix: true,
    headline: "Two cores, no shared arsenal",
    read: "OnKamii ranks Nameless Sword with Infernal Twinblades at T0, fifth overall. Different styles. Each Inner Way only works on its own weapon.",
    arsenal: "General",
    arsenalWhy: "Bellstrike and Bamboocut do not share an attack type. General raises minimum and maximum physical attack for both.",
    source: "OnKamii, Sept 19 2026. He did not publish sockets. Echoes of Oblivion and Sword Morph are the tomes that only work on each weapon.",
    arena: {
      inner: [art("infernal-twinblades").signature, art("nameless-sword").signature, chant, evasive],
      mystic: [serene, talon, cloudSteps, ghostly],
      offense: swallow,
      defense: calmwaters,
      gearNote: "Swallowcall matches the twinblade lights. The sword would rather proc Hawkwing. You cannot wear both 4-pieces. Pick the weapon you spend more time on.",
      stats: [
        { name: "Precision Rate", target: "Near 100%", detail: "Wind's number. This mix is not a Splendor affinity build." },
        { name: "Critical Rate", target: "Around 70%", detail: "Wind's Swallowcall band." },
        { name: "Min Physical Attack", target: "Then max", detail: "General arsenal. There is no shared style attack." },
        { name: "Affinity Rate", target: "Modest", detail: "Enough for Sword Morph. Echoes of Oblivion is not an affinity tome." },
      ],
      loop: "Twinblades for the pressure. Sword when Qi Shield is up and the charged flurry will land. Dodge out instead of parrying yourself into a Wind punish.",
      note: "Rank is cited. The four Inner Ways are the two weapon mechanics plus the ranked flex.",
    },
  },
  {
    ids: ["nameless-spear", "heavenwill-gauntlets"],
    arenaRank: "T0",
    board: "Mix",
    mix: true,
    headline: "The spear sets the table, the gauntlet takes it",
    read: "OnKamii called Nameless Spear with Heavenwill Gauntlets the strongest pair this patch. The spear's Qiankun's Lock is the Tenacity answer the gauntlet does not have. Only the gauntlet charge gets through a held block.",
    arsenal: "General",
    arsenalWhy: "Bellstrike spear, Bamboocut gauntlets. General is the arsenal that boosts both.",
    source: "OnKamii, Sept 19 2026. He did not publish the four sockets. Mountain's Might and Soaring High are the tomes that change each weapon.",
    arena: {
      inner: [art("heavenwill-gauntlets").signature, art("nameless-spear").signature, chant, evasive],
      mystic: [serene, cloudSteps, dragonsBreath, toad],
      offense: swallow,
      defense: calmwaters,
      gearNote: "No set was named for this mix. Swallowcall fits spear lights and a gauntlet cash-out. Hawkwing only if your Heaven's Will procs are affinity.",
      stats: [
        { name: "Precision Rate", target: "High", detail: "A spear poke that misses does not set the gauntlet up." },
        { name: "Min Physical Attack", target: "Then max", detail: "General arsenal. No shared style attack." },
        { name: "Critical Rate", target: "On the cash-out", detail: "The gauntlet hit is the one that should crit." },
        { name: "Max HP", target: "Enough to step in", detail: "You are walking into gauntlet range on purpose." },
      ],
      loop: "Spear poke and Qiankun's Lock to create the step-in. Gauntlets spend Heaven's Will. If they block, use the charge. Leave before you are the one being cashed out.",
      note: "Rank is OnKamii's. Sockets are the weapon mechanics plus the 1v1 flex, because he did not publish a card.",
    },
  },
  {
    ids: ["heavenwill-gauntlets", "infernal-twinblades"],
    arenaRank: "T0",
    board: "Mix",
    mix: true,
    headline: "Two Bamboocut cash-outs",
    read: "OnKamii says Heavenwill with Infernal Twinblades may be the first or second pair in the game, depending on the player. Both are Bamboocut. He did not film the sockets.",
    arsenal: "Bamboocut",
    arsenalWhy: "Shared style. A Bamboocut arsenal raises both.",
    source: "OnKamii, Sept 19 2026. Soaring High and Echoes of Oblivion are the tomes that only function on each weapon.",
    arena: {
      inner: [art("heavenwill-gauntlets").signature, art("infernal-twinblades").signature, chant, evasive],
      mystic: [serene, ghostly, talon, toad],
      offense: swallow,
      defense: calmwaters,
      gearNote: "Swallowcall, the PvP weapon set on the dual-blades page.",
      stats: [
        { name: "Precision Rate", target: "About 100%", detail: "Wind's number. The gauntlet charge is one hit." },
        { name: "Critical Rate", target: "70–73% on Swallowcall", detail: "Game8's Swallowcall band." },
        { name: "Bamboocut Attack", target: "Arsenal", detail: "Heavenwill's talent reads this stat." },
        { name: "Min Physical Attack", target: "Then max", detail: "The blades are many small hits." },
      ],
      loop: "Blades to build pressure. Gauntlets only when Heaven's Will will land. If they hold block, the charge is the hit. If they parry Rodent Rampage, Ghostly Steps and stop.",
      note: "Rank is cited. Not a filmed card.",
    },
  },
  {
    ids: ["heavenwill-gauntlets", "mortal-rope-dart"],
    arenaRank: "T0",
    board: "Mix",
    mix: true,
    headline: "Dart pressure, gauntlet cash-out",
    read: "OnKamii lists Heavenwill with Mortal Rope Dart in T0. The dart is what they cannot just walk away from. The gauntlet is the hit.",
    arsenal: "Bamboocut",
    arsenalWhy: "Both weapons are Bamboocut.",
    source: "OnKamii, Sept 19 2026, T0. Vendetta and Soaring High are the tomes that change these weapons.",
    arena: {
      inner: [art("heavenwill-gauntlets").signature, art("mortal-rope-dart").signature, chant, evasive],
      mystic: [serene, ghostly, talon, cloudSteps],
      offense: swallow,
      defense: calmwaters,
      gearNote: "Swallowcall, from the Wind page. No separate card exists for this mix.",
      stats: [
        { name: "Precision Rate", target: "About 100%", detail: "Wind's number." },
        { name: "Critical Rate", target: "70–73%", detail: "Swallowcall band." },
        { name: "Bamboocut Attack", target: "Arsenal", detail: "Feeds the gauntlet talent." },
        { name: "Min Physical Attack", target: "Then max", detail: "Dart chip and light attacks." },
      ],
      loop: "Tag with the dart and keep the passive up. Spend Heaven's Will when they are already in the string. Hold the charge for the block.",
      note: "Rank is cited. Sockets are mechanics plus the ranked flex.",
    },
  },
  {
    ids: ["thundercry-blade", "snowparting-blade"],
    arenaRank: "T0.5",
    board: "Mix",
    mix: true,
    headline: "The easy Stonesplit win",
    read: "OnKamii suggests Thundercry with Snowparting when you want a pair that wins a lot. T0.5. It is not the Strength ceiling and it is not the Might tank spear.",
    arsenal: "Stonesplit",
    arsenalWhy: "Both weapons are Stonesplit.",
    source: "OnKamii, Sept 19 2026, T0.5. Frost-Clad Night is the deflect tome. Exquisite Scenery is the parry tome. Game8 pulls Throat-Piercing off in PvP.",
    arena: {
      inner: [art("snowparting-blade").signature, art("thundercry-blade").signature, chant, leech],
      mystic: [serene, golden, talon, toad],
      offense: shattered,
      defense: agile,
      gearNote: "Agile Steps is the Strength PvP armor. Shattered Ridge is the weapon set on that sheet.",
      stats: [
        { name: "Precision Rate", target: "95–100%", detail: "Game8's Strength number." },
        { name: "Critical Rate", target: "75–80%", detail: "Snowparting band. Not the Phalanxbane boss plan." },
        { name: "Max Physical Attack", target: "Then minimum", detail: "After the rates." },
        { name: "Stonesplit Attack", target: "Arsenal", detail: "Shared style." },
      ],
      loop: "Deflect into Finding Spring on Snowparting. Parry into Avalanche when you want Exquisite Scenery. Do not hold Throat-Piercing stacks on a player.",
      note: "Rank is OnKamii's. The bar is the two weapon mechanics plus Game8's PvP swaps.",
    },
  },
  {
    ids: ["museflow-drum", "willowbend-fan"],
    arenaRank: "—",
    board: "New",
    mix: false,
    headline: "Buff first, then one melody",
    read: "Silkbind — Wings arrived October 15, 2026, so it is not on the Sept 19 1v1 board. The Oct 16 guide rates it S in guild battles and much weaker in a duel. The pay is Rustling, Radiant Drum, a shield, and a knockdown, not a solo cash-out.",
    arsenal: "Silkbind",
    arsenalWhy: "Both weapons are Silkbind, so that arsenal raises the fan and the drum.",
    source: "Game8 Silkbind — Wings sheet, October 15, 2026. Guild rank from the October 16 guide-site list. No high-rank 1v1 share yet.",
    arena: {
      inner: [art("museflow-drum").signature, art("willowbend-fan").signature, art("museflow-drum").second, chant],
      mystic: [soaring, toad, serene, cloudSteps],
      offense: cloudshear,
      defense: reinchime,
      gearNote: "Cloudshear and Reinchime both turn on when you apply Rustling or Radiant Drum. Boss-damage lines from the PvE sheet are left off.",
      stats: [
        { name: "Precision Rate", target: "The melody has to land", detail: "End of Gale and Rippling Dew do nothing if they are already out of the arc." },
        { name: "Min Physical Attack", target: "Then Silkbind", detail: "Game8's Wings damage sheet wants minimum physical attack, not a boss modifier." },
        { name: "Silkbind Attack", target: "Arsenal", detail: "Shared style. A General arsenal leaves both weapons behind." },
        { name: "Agility", target: "The beat", detail: "The drum skills have a timing window. Agility is the stat on that sheet after the attack lines." },
      ],
      loop: "Fan first: Boreal Sweep, Boundless Bloom for Rustling, End of Gale. Drum only when Noble Will is at 100. Rippling Dew into Jadebreaker for the duel, Dawnsun if you need the shield. Plumage Sweep and Rhythm of Accord refill it. Do not stand in three heavy attacks if they can leave.",
      note: "No filmed 1v1 bar. The fourth Inner Way is Morale Chant, the slot Game8 keeps until the fight is a crowd. Blade's Will does not stack on one person.",
    },
    group: {
      inner: [art("museflow-drum").signature, art("willowbend-fan").signature, art("museflow-drum").second, art("willowbend-fan").second],
      mystic: [flute, soaring, toad, serene],
      loop: "Keep Rustling and Radiant Drum on the team. Toneflux for the knockdown, Dawnsun when the shield is the job. Blade's Will is the crowd root. Cancel Flute of the Tides after the first hit, then the fan setup. Do not channel a long heavy while you are surrounded.",
      note: "This is the mode the path is rated for. S in guild battles on the October 16 list. The 1v1 desk is the thinner version.",
    },
  },
];

type Play = {
  does: string;
  lacks: string;
  open: string;
  cash: string;
  many: boolean;
  bleed: boolean;
  shield: boolean;
  heal: boolean;
  catch: boolean;
  drunk: boolean;
  wind: boolean;
  blockCharge: boolean;
};

const PLAY: Record<string, Play> = {
  "nameless-sword": { does: "raises Qi Shield, then a charged attack spends endurance and throws sword energy", lacks: "a way to hold them still. The flurry is deflectable if you throw it from a distance they expect.", open: "Fearless Lunge or the martial skill, so Qi Shield is up before you charge", cash: "the charged flurry only while the shield is up", many: true, bleed: false, shield: false, heal: false, catch: false, drunk: false, wind: false, blockCharge: false },
  "nameless-spear": { does: "pokes and immobilizes with Qiankun's Lock, which is the Tenacity answer", lacks: "a big cash-out. The spear spends endurance to move and to hit.", open: "Qiankun's Lock when they commit, not on cooldown", cash: "a short punish, then stop. Mountain's Might is what refunds the endurance", many: true, bleed: false, shield: false, heal: false, catch: true, drunk: false, wind: false, blockCharge: false },
  "strategic-sword": { does: "follows its own martial, charged, or special with a cross-slash that applies bleed", lacks: "a catch. Bleed does nothing if they run, and Sword Horizon does not function on any other weapon.", open: "a Strategic Sword skill, not the other weapon's", cash: "the Horizon follow-up, then stay on the sword until the bleed matters", many: false, bleed: true, shield: false, heal: false, catch: false, drunk: false, wind: false, blockCharge: false },
  "heavenquaker-spear": { does: "fills its martial buff in fewer hits, and a bleeding body can grant an extra point", lacks: "the bleed itself. Wolfchaser does not apply bleed.", open: "only after the target is bleeding", cash: "the shortened spear string", many: true, bleed: true, shield: false, heal: false, catch: false, drunk: false, wind: false, blockCharge: false },
  "infernal-twinblades": { does: "stacks ignore-defense damage on light attacks and keeps a rage loop if Rodent Rampage is not parried", lacks: "a safe way out once they start parrying the rage skill.", open: "light attacks to build the stack", cash: "the rage window, then leave before the parry", many: true, bleed: false, shield: false, heal: false, catch: true, drunk: false, wind: true, blockCharge: false },
  "mortal-rope-dart": { does: "chases and keeps passive damage up so they cannot just walk away", lacks: "the cash-out. The dart sets the range.", open: "a tag that starts the passive", cash: "pressure, not a single nuke", many: true, bleed: false, shield: false, heal: false, catch: true, drunk: false, wind: true, blockCharge: false },
  "everspring-umbrella": { does: "plays Resonance and repositions. The throw shows a warning flash", lacks: "a silent opener.", open: "a mix-up, not the same throw twice", cash: "Resonance while Phantom Rally is socketed", many: true, bleed: false, shield: false, heal: false, catch: false, drunk: false, wind: false, blockCharge: false },
  "unfettered-rope-dart": { does: "sweeps. Towline Sweep is the dart's own tome", lacks: "a 1v1 control payoff. Light Anew wants more than one body.", open: "the sweep when they are already in the arc", cash: "the bodies the sweep actually hits", many: true, bleed: false, shield: false, heal: false, catch: true, drunk: false, wind: false, blockCharge: false },
  "heavenwill-gauntlets": { does: "cashes Heaven's Will in melee. Only the charge gets through a held block", lacks: "an answer to Tenacity.", open: "only when Heaven's Will will land", cash: "the charge if they block, the string if they do not", many: false, bleed: false, shield: false, heal: false, catch: false, drunk: false, wind: false, blockCharge: true },
  "skygrasp-rope-dart": { does: "sets the handoff into the gauntlet, then leaves", lacks: "the damage. Sky Gripped is the setup tome.", open: "the dart setup", cash: "the swap, then out", many: true, bleed: false, shield: false, heal: false, catch: true, drunk: false, wind: false, blockCharge: false },
  "skystrike-gauntlets": { does: "deals its damage inside a short Inebriate window", lacks: "time. An interrupt wastes Drunkslay.", open: "enter Inebriate before you swap", cash: "the detonation when the debuff ends", many: false, bleed: false, shield: false, heal: false, catch: false, drunk: true, wind: false, blockCharge: false },
  "riven-twinblades": { does: "extends Deepdaze so a weapon swap fits inside the drunken window", lacks: "the window itself. Skyspeak does not create Inebriate.", open: "only after Inebriate is already up", cash: "the extended Deepdaze, then stop", many: true, bleed: false, shield: false, heal: false, catch: false, drunk: true, wind: false, blockCharge: false },
  "vernal-umbrella": { does: "fights at range, stuns, and makes them miss before you step in", lacks: "the melee punish.", open: "a projectile or the ranged stun", cash: "only after they have already whiffed", many: true, bleed: false, shield: false, heal: false, catch: true, drunk: false, wind: false, blockCharge: false },
  "inkwell-fan": { does: "teleports into the punish once they have missed. The guard break is why the path ranks", lacks: "a safe opener.", open: "after the miss, not before it", cash: "the teleport punish", many: false, bleed: false, shield: false, heal: false, catch: false, drunk: false, wind: false, blockCharge: false },
  "panacea-fan": { does: "heals. Royal Remedy is the loop", lacks: "kill pressure. In 1v1 the win can be damage dealt if nobody dies.", open: "a heal or a cleanse, then move", cash: "surviving until their engage runs out of endurance", many: false, bleed: false, shield: false, heal: true, catch: false, drunk: false, wind: false, blockCharge: false },
  "soulshade-umbrella": { does: "gives the fan its resources back", lacks: "damage. Esoteric Revival is a group pickup.", open: "the recovery cast between heals", cash: "the next fan cast, not a combo", many: false, bleed: false, shield: false, heal: true, catch: false, drunk: false, wind: false, blockCharge: false },
  "thundercry-blade": { does: "parries into Avalanche. Exquisite Scenery skips a phase of that skill", lacks: "a chase. People run from Might and chip it.", open: "a parry you chose, not a dodge", cash: "the shortened Avalanche", many: false, bleed: false, shield: true, heal: false, catch: false, drunk: false, wind: false, blockCharge: false },
  "stormbreaker-spear": { does: "taunts with Storm Roar and takes damage reduction from Rock Solid, at the cost of 10% of your damage", lacks: "kill speed.", open: "Storm Roar when they are already on you", cash: "the reduction window, then the blade's parry", many: false, bleed: false, shield: true, heal: false, catch: true, drunk: false, wind: false, blockCharge: false },
  "snowparting-blade": { does: "deflects, then Finding Spring spends Blade Momentum and grants Tenacity", lacks: "a long charge. The PvP loop is one bar and leave.", open: "a deflect", cash: "one Finding Spring, then out", many: false, bleed: false, shield: false, heal: false, catch: false, drunk: false, wind: false, blockCharge: false },
  "phalanxbane-blade": { does: "stacks Throat-Pierced on a body that stands in the combo", lacks: "a player who will stand there. Game8 takes the tome off in PvP for that reason.", open: "only on a target that is already stunned", cash: "the charged string, or nothing", many: false, bleed: false, shield: false, heal: false, catch: false, drunk: false, wind: false, blockCharge: false },
  "museflow-drum": { does: "spends 100 Noble Will on Rippling Dew: Jadebreaker for damage, Dawnsun for a shield, or Toneflux for a knockdown", lacks: "a solo cash-out. The drum is a team buff that also hits.", open: "only after the fan has Rustling up and Noble Will is full", cash: "one melody, then refill with Plumage Sweep and Rhythm of Accord", many: true, bleed: false, shield: true, heal: false, catch: true, drunk: false, wind: false, blockCharge: false },
  "willowbend-fan": { does: "opens with Boreal Sweep, puts Rustling on you and nearby allies, and refills Noble Will with End of Gale", lacks: "the melody. The fan sets the buff and then leaves.", open: "the fan, before the drum", cash: "Rustling and the Noble Will, then swap", many: true, bleed: false, shield: false, heal: false, catch: false, drunk: false, wind: false, blockCharge: false },
};

export type DeskView = {
  primary: Art;
  partner: Art;
  pairLabel: string;
  mix: boolean;
  offPath: boolean;
  arenaRank: string;
  board: string;
  headline: string;
  read: string;
  arsenal: string;
  arsenalWhy: string;
  source: string;
  usage: string;
  modeNote: string | null;
  inner: Slot[];
  mystic: Slot[];
  offense: SetBonus;
  defense: SetBonus;
  gearNote: string;
  stats: Stat[];
  loop: string;
};

export function getArt(id: string): Art {
  return art(id);
}

export function suggestionsFor(id: string): Suggestion[] {
  return suggest[id] ?? [];
}

export function designedPartner(id: string): string {
  return suggestionsFor(id)[0]?.id ?? id;
}

function findDuo(a: string, b: string): Duo | undefined {
  return DUOS.find(
    (duo) =>
      (duo.ids[0] === a && duo.ids[1] === b) || (duo.ids[0] === b && duo.ids[1] === a),
  );
}

function pickMode(duo: Duo, mode: Mode): ModeDesk {
  if (mode === "arena" || !duo.group) {
    return {
      ...duo.arena,
      note:
        mode === "group"
          ? (duo.sameNote ?? duo.group?.note ?? "No separate group sheet. This is the 1v1 desk.")
          : duo.arena.note,
    };
  }
  const group = duo.group;
  return {
    inner: group.inner ?? duo.arena.inner,
    mystic: group.mystic ?? duo.arena.mystic,
    offense: group.offense ?? duo.arena.offense,
    defense: group.defense ?? duo.arena.defense,
    gearNote: group.gearNote ?? duo.arena.gearNote,
    stats: group.stats ?? duo.arena.stats,
    loop: group.loop ?? duo.arena.loop,
    note: group.note ?? duo.arena.note,
  };
}
function hybrid(primary: Art, partner: Art, mode: Mode): DeskView {
  const lead = PLAY[primary.id];
  const off = PLAY[partner.id];
  const same = primary.style === partner.style;
  const healer = lead.heal || off.heal;
  const wind = lead.wind || off.wind;
  const bleed = lead.bleed || off.bleed;
  const shield = lead.shield || off.shield;
  const drunk = lead.drunk || off.drunk;
  const hasCatch = lead.catch || off.catch;
  const charge = lead.blockCharge || off.blockCharge;
  const many = lead.many || off.many;
  const bothHeal = lead.heal && off.heal;
  const bothDrunk = lead.drunk && off.drunk;
  const spearBleed =
    (primary.id === "heavenquaker-spear" || partner.id === "heavenquaker-spear") &&
    primary.id !== "strategic-sword" &&
    partner.id !== "strategic-sword";

  const banned = new Set(
    mode === "arena"
      ? ["Battle Anthem", "Throat-Piercing Art", "Esoteric Revival", "Light Anew", "Steadfast Devotion"]
      : ["Battle Anthem"],
  );

  const working = (art: Art): Slot | null => {
    if (!banned.has(art.signature.name)) return art.signature;
    if (!banned.has(art.second.name)) return { ...art.second, tag: "Instead" };
    return null;
  };

  const support = (art: Art): Slot | null => {
    if (banned.has(art.second.name)) return null;
    if (art.second.name === art.signature.name) return null;
    const name = art.second.name;
    if (name === "Wildfire Spark") return art.second;
    if (name === "Volutefit" && drunk) return art.second;
    if (name === "Art of Resistance" && shield) return art.second;
    if (name === "Fivefold Bleed" && bleed) return art.second;
    if (name === "Adaptive Steel") return art.second;
    if (name === "Restoring Blossom" && healer) return art.second;
    if (name === "Breaking Point" && mode === "arena") return art.second;
    if (name === "Light Anew" && mode === "group") return art.second;
    return null;
  };

  const inner: Slot[] = [];
  const push = (slot: Slot | null) => {
    if (!slot || inner.length >= 4 || inner.some((have) => have.name === slot.name)) return;
    inner.push(slot);
  };
  const dropped = [primary, partner].filter((art) => !working(art));
  push(working(primary));
  push(working(partner));
  push(support(primary));
  push(support(partner));
  push(chant);
  push(mode === "arena" ? evasive : fury);
  push(shield ? leech : mode === "arena" ? fury : evasive);

  const mystic: Slot[] = [];
  const add = (slot: Slot) => {
    if (mystic.length >= 4 || mystic.some((have) => have.name === slot.name)) return;
    mystic.push(slot);
  };
  add({
    ...serene,
    detail: `Still the first mystic. ${primary.name} and ${partner.name} do not get you out of a combo. After the upgrade, a long control auto-breaks into brief Super Armor.`,
  });
  if (healer) {
    add({
      ...freeMorph,
      detail: `The healer's way out. ${lead.heal ? primary.name : partner.name} dies if it cannot leave. This does not turn the fan into a damage weapon.`,
    });
  }
  if (!hasCatch) {
    add({
      ...cloudSteps,
      detail: `Neither weapon immobilizes. ${lead.lacks} Cloud Steps is the gap, because a cash-out that never arrives is not a plan.`,
    });
  }
  if (wind) add(ghostly);
  if (charge) add(talon);
  if (shield || drunk) add(golden);
  if (hasCatch && !healer) {
    add({
      ...dragonsBreath,
      detail: `Burst only after the catch. ${hasCatch ? "Something in this pair can stop them." : ""} Do not open with Breath. The fortitude is so the follow-up is not slapped out.`,
    });
  }
  add(toad);
  if (mode === "group" && !hasCatch) {
    add({
      name: "Meridian Touch",
      tag: "Hold",
      cited: true,
      detail: "A ranged hold for a pile. Use it when the opener still cannot make a body stand still.",
    });
  }

  const catcher = lead.catch ? primary : off.catch ? partner : null;
  const casher = catcher && catcher.id === primary.id ? partner : catcher ? primary : null;
  const catchPlay = catcher && catcher.id === primary.id ? lead : catcher ? off : null;
  const cashPlay = casher && casher.id === primary.id ? lead : casher ? off : null;

  let headline: string;
  let read: string;
  let loop: string;

  if (bothHeal) {
    headline = "Two recovery tools. Nothing in the pair is the kill.";
    read = `${primary.name} ${lead.does} ${partner.name} ${off.does} In 1v1 the match is decided by damage dealt if nobody dies. This pairing can stall. It cannot close.`;
    loop = "Heal, leave, heal again. Do not walk in to trade. If you wanted a kill weapon, this is the wrong second art.";
  } else if (healer) {
    const damage = lead.heal ? partner : primary;
    const damagePlay = lead.heal ? off : lead;
    headline = `${damage.name} has to get the kill. The fan only buys time.`;
    read = `${damage.name} ${damagePlay.does} The healer side ${lead.heal ? lead.does : off.does} What the damage weapon still does not do: ${damagePlay.lacks}`;
    loop = `Keep the fan casting between engages. ${damage.name}: ${damagePlay.open}. ${damagePlay.cash}. Leave with Free Morph when the engage fails. Do not spend the healer's endurance on a second damage rotation.`;
  } else if (drunk && !bothDrunk) {
    headline = "The drunken window never starts unless Skystrike opens it.";
    read = "Eonpour raises damage inside Inebriate and, at high tier, stores Drunkslay. Skyspeak only extends Deepdaze. It does not create the drunk state. A partner that is not the Draught gauntlet cannot turn this on.";
    loop = "If Skystrike is in your hands, enter Inebriate first, then swap. If it is not, this pair has no drunken payoff. Play the other weapon's own loop and treat the Draught piece as dead weight.";
  } else if (bothDrunk) {
    headline = "Open the drunk window, then spend it before it closes.";
    read = "Eonpour raises damage inside Inebriate and, at high tier, stores Drunkslay. Skyspeak only extends Deepdaze so the swap fits. It does not create the drunk state. OnKamii calls the designed pair the most ping-dependent T0. An interrupt wastes the stored hit.";
    loop = "Enter Inebriate on the gauntlets first. Swap to the twinblades while Deepdaze is extended. Detonate as the debuff ends. If you cannot finish the window, do not swap.";
  } else if (spearBleed) {
    headline = "Wolfchaser is waiting on a bleed this pair does not apply.";
    read = "Wolfchaser's Art lowers how many hits Heavenquaker needs, and a bleeding body can grant an extra point. Nothing here applies that bleed. Sword Horizon only functions on Strategic Sword, which is not equipped.";
    loop = "Do not open on Heavenquaker expecting the Umbra payoff. Use the other weapon for what it actually does, and treat the spear as a shorter combo with no extra point.";
  } else if (catcher && casher && catchPlay && cashPlay) {
    headline = `${catcher.name} makes the opening. ${casher.name} has to spend it.`;
    read = `${catcher.name} ${catchPlay.does} ${casher.name} ${cashPlay.does} The hole that is still open: ${cashPlay.lacks}`;
    loop = `${catcher.name}: ${catchPlay.open}. Then ${casher.name}: ${cashPlay.cash}. When their Serene Breeze comes up, stop. Do not spend the second weapon's resource on an opener the first weapon already missed.`;
  } else if (lead.blockCharge || off.blockCharge) {
    headline = "They can hold block. Only the gauntlet charge gets through.";
    read = `${primary.name} ${lead.does} ${partner.name} ${off.does} OnKamii's counter to Heavenwill is holding block. If the other weapon cannot break that block or catch through Tenacity, the charge is the whole offense.`;
    loop = "Save Heaven's Will for the charge when they block. Use the other weapon to create the step-in. Talon Strike is the mystic that breaks the block if the charge is on cooldown.";
  } else {
    headline = `${primary.name} leads. ${partner.name} has to cover the hole.`;
    read = `${primary.name} ${lead.does} What it does not do: ${lead.lacks} ${partner.name} ${off.does} What that still does not do: ${off.lacks}`;
    loop = `${primary.name}: ${lead.open}. ${lead.cash}. ${partner.name}: ${off.open}. ${off.cash}. If the second weapon never answers the first weapon's hole, the pair is two openers and no plan.`;
  }

  const offense = healer ? ivory : bleed ? hawkwing : many ? swallow : shield ? shattered : hawkwing;
  const defense = healer ? rainwhisper : shield ? agile : calmwaters;

  return {
    primary,
    partner,
    pairLabel: "How it could work",
    mix: true,
    offPath: true,
    arenaRank: "—",
    board: "—",
    headline,
    read,
    arsenal: same ? primary.style : "General",
    arsenalWhy: same
      ? `Both weapons are ${primary.style}, so that arsenal still raises both.`
      : `${primary.style} and ${partner.style} do not share an attack type. General raises minimum and maximum physical attack for both. A single-style arsenal would leave one weapon behind.`,
    source:
      "No ranked player published this pair. The Inner Ways are the tomes that function on these weapons. A boss mod, a stack a player will not let you hold, and a revive are left off in 1v1. Morale Chant and Evasive Charge are the flex from filmed 1v1 bars. The percent is a model of the Sept 19 high-rank board, not a counted ladder.",
    usage: playerShare(primary.id, partner.id),
    modeNote: [
      mode === "group"
        ? "Group: Fury Harvest keeps mystic arts up. Throat-Piercing and Light Anew can come back when more than one body will actually sit in the effect."
        : "Arena: Evasive Charge refunds endurance on a perfect dodge. It does nothing if you only block or eat the hit.",
      dropped.length
        ? `${dropped.map((art) => art.name).join(" and ")} ${dropped.length > 1 ? "have" : "has"} no tome that works on a player here. ${dropped.map((art) => PLAY[art.id].lacks).join(" ")}`
        : "",
    ]
      .filter(Boolean)
      .join(" "),
    inner,
    mystic,
    offense,
    defense,
    gearNote: healer
      ? "Ivorybloom is the crit-heal set on the Deluge sheet. Rainwhisper is the armor. Hawkwing does not turn a healer into a damage path."
      : bleed
        ? "Hawkwing, because the 4-piece pays when affinity procs and bleed already lives in that band. A fit for the mechanic, not a filmed card for this mix."
        : many
          ? "Swallowcall. The 2-piece is minimum physical attack, which is what light attacks and sweeps actually use."
          : shield
            ? "Agile Steps if the job is to deflect and still be alive. Shattered Ridge only if this pair is the Stonesplit damage, not the tank."
            : "Hawkwing only if the lead procs affinity. Otherwise the 4-piece is a bonus for a hit type you do not have.",
    stats: [
      {
        name: "Precision Rate",
        target: many ? "About 100%" : "The opener has to hit",
        detail: many
          ? "Light attacks and sweeps fall off a cliff when they miss. Wind sheets sit near 100%."
          : "A catch, a deflect follow-up, or a charge that misses is not a combo.",
      },
      healer
        ? {
            name: "Critical Rate",
            target: "For the heal",
            detail: "Restoring Blossom pays critical healing. A damage crit does not fix a pair with no kill tool.",
          }
        : bleed
          ? {
              name: "Affinity Rate",
              target: "Feed the bleed",
              detail: "Enough for the bleed and for Hawkwing. Do not copy a Splendor affinity cap onto a pair that was never that build.",
            }
          : {
              name: "Critical Rate",
              target: many ? "70–73% on Swallowcall" : "After precision",
              detail: "A crit on a miss is nothing. Match the number to the set you actually wear.",
            },
      {
        name: same ? `Max ${primary.style} Attack` : "Min Physical Attack",
        target: same ? "Arsenal" : "Then max",
        detail: same
          ? "Shared style, so the style attack is a real stat on both weapons."
          : "General arsenal. One style's attack stat leaves the other weapon behind.",
      },
      {
        name: "Max HP",
        target: shield ? "Enough to stand in the hit" : "Enough for one engage",
        detail: shield
          ? "A parry plan assumes you are alive when the reduction ends."
          : "This pair has no published shield. Do not buy health by dumping precision.",
      },
    ],
    loop,
  };
}export function resolveDesk(primaryId: string, partnerId: string, mode: Mode): DeskView {
  const primary = getArt(primaryId);
  const partner = getArt(partnerId === primaryId ? designedPartner(primaryId) : partnerId);
  const duo = findDuo(primary.id, partner.id);
  if (!duo) return hybrid(primary, partner, mode);

  const sheet = pickMode(duo, mode);
  const suggestion = suggestionsFor(primary.id).find((item) => item.id === partner.id);
  return {
    primary,
    partner,
    pairLabel: suggestion?.label ?? (duo.mix ? "Ranked mix" : "Path pair"),
    mix: duo.mix,
    offPath: false,
    arenaRank: duo.arenaRank,
    board: duo.board,
    headline: duo.headline,
    read: duo.read,
    arsenal: duo.arsenal,
    arsenalWhy: duo.arsenalWhy,
    source: duo.source,
    usage: playerShare(primary.id, partner.id),
    modeNote: sheet.note ?? null,
    inner: sheet.inner,
    mystic: sheet.mystic,
    offense: sheet.offense,
    defense: sheet.defense,
    gearNote: sheet.gearNote,
    stats: sheet.stats,
    loop: sheet.loop,
  };
}

export function deskText(view: DeskView, mode: Mode): string {
  const modeLabel = mode === "arena" ? "1v1 Arena" : "Group fight";
  const lines = [
    `Jianghu Builder · ${modeLabel}`,
    `${view.primary.name} + ${view.partner.name}`,
    `${view.primary.path} · ${view.pairLabel} · ${view.usage} of players`,
    "",
    view.headline,
    view.read,
    "",
    "Inner Ways",
    ...view.inner.map((slot, index) => `${index + 1}. ${slot.name} — ${slot.detail}`),
    "",
    "Mystic Arts",
    ...view.mystic.map((slot) => `- ${slot.name} — ${slot.detail}`),
    "",
    "Items",
    `Offense: ${view.offense.name} (${view.offense.where}). ${view.offense.bonus}`,
    `Defense: ${view.defense.name} (${view.defense.where}). ${view.defense.bonus}`,
    view.gearNote,
    "",
    "PvP attributes",
    ...view.stats.map((stat, index) => `${index + 1}. ${stat.name} — ${stat.target}. ${stat.detail}`),
    "",
    `Arsenal: ${view.arsenal}. ${view.usage} of players in PvP have used this build. ${view.arsenalWhy}`,
    "",
    view.loop,
    "",
    view.source,
  ];
  return lines.join("\n");
}

export function audit(): string[] {
  const problems: string[] = [];
  const ids = new Set(ARTS.map((entry) => entry.id));
  if (ids.size !== ARTS.length) problems.push("Duplicate art ids");
  if (Object.keys(PLAY).length !== ARTS.length) problems.push("Playbook missing an art");
  for (const entry of ARTS) {
    const list = suggestionsFor(entry.id);
    if (list.length === 0) problems.push(`No suggestions for ${entry.id}`);
    if (!PLAY[entry.id]) problems.push(`No playbook for ${entry.id}`);
    for (const item of list) {
      if (!ids.has(item.id)) problems.push(`Bad suggestion ${item.id} on ${entry.id}`);
      if (item.id === entry.id) problems.push(`Self suggestion ${entry.id}`);
    }
  }
  for (const duo of DUOS) {
    if (!ids.has(duo.ids[0]) || !ids.has(duo.ids[1])) problems.push(`Bad duo ${duo.ids.join("+")}`);
    if (duo.arena.inner.length !== 4) problems.push(`Inner count ${duo.ids.join("+")} arena ${duo.arena.inner.length}`);
    if (duo.group?.inner && duo.group.inner.length !== 4) problems.push(`Inner count ${duo.ids.join("+")} group`);
  }
  return problems;
}
