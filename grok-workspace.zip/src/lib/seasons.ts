export type Season = {
  id: string;
  label: string;
  start: string;
  end: string;
  ink: string;
  lacquer: string;
  panel: string;
  line: string;
  paper: string;
  paperDeep: string;
  rule: string;
  dim: string;
  inkSoft: string;
  cinnabar: string;
  mark: string;
  glow: string;
  tide: string;
};

const BETWEEN: Season = {
  id: "between",
  label: "Between seasons",
  start: "",
  end: "",
  ink: "#121416",
  lacquer: "#1a1e22",
  panel: "#24282c",
  line: "#3a4046",
  paper: "#eef1f2",
  paperDeep: "#d8dee2",
  rule: "#c5ced4",
  dim: "#9aa3aa",
  inkSoft: "#555c62",
  cinnabar: "#8aa0ae",
  mark: "#4d6270",
  glow: "#1e2a32",
  tide: "#14181c",
};

// Season windows follow the published resets at 05:00 UTC+8.
// Game8's season list, checked October 16, 2026. The end instant is exclusive.
export const SEASONS: Season[] = [
  {
    id: "blade-out",
    label: "Season 1 · Blade Out",
    start: "2025-11-15T05:00:00+08:00",
    end: "2026-02-06T05:00:00+08:00",
    ink: "#12110e",
    lacquer: "#1c1914",
    panel: "#262218",
    line: "#3a332b",
    paper: "#f4efe4",
    paperDeep: "#e7dcc8",
    rule: "#d9cdb8",
    dim: "#a89b88",
    inkSoft: "#5e564c",
    cinnabar: "#c4492a",
    mark: "#a33b22",
    glow: "#3a1c14",
    tide: "#1a1814",
  },
  {
    id: "rewind",
    label: "Season 2 · Rewind",
    start: "2026-02-06T05:00:00+08:00",
    end: "2026-04-30T05:00:00+08:00",
    ink: "#161014",
    lacquer: "#241820",
    panel: "#2e2228",
    line: "#4a3840",
    paper: "#f8efe8",
    paperDeep: "#efd8cc",
    rule: "#e0c4b4",
    dim: "#b89aa0",
    inkSoft: "#6a534c",
    cinnabar: "#d46a7a",
    mark: "#9c3d52",
    glow: "#4a2430",
    tide: "#1c2430",
  },
  {
    id: "seek-within",
    label: "Season 3 · Seek Within",
    start: "2026-04-30T05:00:00+08:00",
    end: "2026-07-23T05:00:00+08:00",
    ink: "#100e14",
    lacquer: "#1a1622",
    panel: "#241e2c",
    line: "#3c3448",
    paper: "#f3efe6",
    paperDeep: "#e4d8c4",
    rule: "#d4c4a8",
    dim: "#a89cb0",
    inkSoft: "#564e5c",
    cinnabar: "#c9a15a",
    mark: "#8a6230",
    glow: "#3a2040",
    tide: "#141828",
  },
  {
    id: "forged-ahead",
    label: "Season 4 · Forged Ahead",
    start: "2026-07-23T05:00:00+08:00",
    end: "2026-10-15T05:00:00+08:00",
    ink: "#120e0c",
    lacquer: "#1e1612",
    panel: "#2a1e18",
    line: "#4a3428",
    paper: "#f3ebe3",
    paperDeep: "#e6d2c0",
    rule: "#d8c0ac",
    dim: "#b09a8c",
    inkSoft: "#5e4e44",
    cinnabar: "#e07030",
    mark: "#a34818",
    glow: "#5a2410",
    tide: "#1a1210",
  },
  {
    id: "ever-aflame",
    label: "Season 5 · Ever Aflame",
    start: "2026-10-15T05:00:00+08:00",
    end: "2027-01-07T05:00:00+08:00",
    ink: "#101612",
    lacquer: "#17211b",
    panel: "#1e2a24",
    line: "#3d4a3c",
    paper: "#f7f0df",
    paperDeep: "#ead8b0",
    rule: "#d9c59a",
    dim: "#b7aa8c",
    inkSoft: "#5c5646",
    cinnabar: "#e2b04a",
    mark: "#8d5e14",
    glow: "#4a3014",
    tide: "#16302c",
  },
];

export function seasonAt(now = new Date()): Season {
  const time = now.getTime();
  return (
    SEASONS.find((season) => time >= Date.parse(season.start) && time < Date.parse(season.end)) ??
    BETWEEN
  );
}

export function applySeason(season: Season) {
  const root = document.documentElement;
  root.dataset.season = season.id;
  const pairs: [string, string][] = [
    ["--color-ink", season.ink],
    ["--color-lacquer", season.lacquer],
    ["--color-panel", season.panel],
    ["--color-line", season.line],
    ["--color-paper", season.paper],
    ["--color-paper-deep", season.paperDeep],
    ["--color-rule", season.rule],
    ["--color-dim", season.dim],
    ["--color-ink-soft", season.inkSoft],
    ["--color-cinnabar", season.cinnabar],
    ["--color-mark", season.mark],
    ["--season-glow", season.glow],
    ["--season-tide", season.tide],
  ];
  for (const [name, value] of pairs) root.style.setProperty(name, value);
  document.querySelector('meta[name="theme-color"]')?.setAttribute("content", season.ink);
}
