import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { JianghuGate } from "@/components/jianghu-gate";
import { LedgerApp } from "@/components/ledger-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const [entered, setEntered] = useState(false);
  return (
    <>
      <LedgerApp />
      {entered ? null : <JianghuGate onEnter={() => setEntered(true)} />}
    </>
  );
}
